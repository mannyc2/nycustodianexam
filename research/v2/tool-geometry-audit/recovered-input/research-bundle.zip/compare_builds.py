#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def sha(p: Path) -> str:
    h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()

def collect(root: Path):
    return {p.relative_to(root).as_posix(): sha(p) for p in root.rglob('*') if p.is_file() and p.name not in {'SHA256SUMS','determinism-comparison.json'}}

ap=argparse.ArgumentParser(); ap.add_argument('a',type=Path); ap.add_argument('b',type=Path); ap.add_argument('--out',type=Path)
args=ap.parse_args(); a=collect(args.a); b=collect(args.b)
paths=sorted(set(a)|set(b)); diffs=[{'path':p,'a':a.get(p),'b':b.get(p)} for p in paths if a.get(p)!=b.get(p)]
result={'exactMatch':not diffs,'fileCountA':len(a),'fileCountB':len(b),'differences':diffs}
out=args.out or args.a/'determinism-comparison.json'; out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='ascii')
print(json.dumps(result,indent=2)); raise SystemExit(0 if not diffs else 1)
