#!/usr/bin/env python3
"""Deterministic, mechanically-auditable tool-illustration proof of concept.

No third-party geometry, image, texture, logo, or official-exam artwork is embedded.
The models are source-class C prototypes and are not production-approved.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import cadquery as cq
from cadquery import exporters
import cairosvg
import numpy as np
from PIL import Image, ImageOps, ImageDraw
from scipy import ndimage
import trimesh

OBS_DATE = "2026-08-20"
FIXED_TIMESTAMP = "2026-08-20T00:00:00"
SOURCE_DATE_EPOCH = "1787184000"


@dataclass(frozen=True)
class Part:
    private_name: str
    shape: cq.Shape


@dataclass(frozen=True)
class Model:
    asset_key: str
    taxonomy_id: str
    canonical_term: str
    parts: tuple[Part, ...]
    params: dict[str, Any]
    views: dict[str, tuple[float, float, float]]
    feature_parts: tuple[str, ...]
    expected: dict[str, Any]
    source_record: dict[str, Any]

    @property
    def compound(self) -> cq.Compound:
        return cq.Compound.makeCompound([p.shape for p in self.parts])


def json_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="ascii", newline="\n")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def poly_prism(points: list[tuple[float, float]], thickness: float) -> cq.Shape:
    return cq.Workplane("XY").polyline(points).close().extrude(thickness / 2, both=True).val()


def box(length: float, width: float, thickness: float, cx: float, cy: float) -> cq.Shape:
    return cq.Workplane("XY").box(length, width, thickness).translate((cx, cy, 0)).val()


def annular_polygon(cx: float, cy: float, outer_d: float, inner_w: float, inner_h: float, thickness: float, sides: int = 20) -> cq.Shape:
    outer = cq.Workplane("XY").center(cx, cy).polygon(sides, outer_d).extrude(thickness / 2, both=True).val()
    inner = box(inner_w, inner_h, thickness + 2.0, cx, cy)
    return outer.cut(inner)


def tooth_row(x0: float, x1: float, baseline_y: float, height: float, count: int, thickness: float, direction: int) -> cq.Shape:
    shapes: list[cq.Shape] = []
    pitch = (x1 - x0) / count
    for i in range(count):
        a = x0 + i * pitch
        b = a + pitch * 0.84
        m = (a + b) / 2
        if direction > 0:
            pts = [(a, baseline_y), (b, baseline_y), (m, baseline_y + height)]
        else:
            pts = [(a, baseline_y), (m, baseline_y - height), (b, baseline_y)]
        shapes.append(poly_prism(pts, thickness))
    return cq.Compound.makeCompound(shapes)


def revolved_shell(profile: list[tuple[float, float]]) -> cq.Shape:
    # (radius, z) points; Workplane XZ local Y is global Z.
    return cq.Workplane("XZ").polyline(profile).close().revolve(360, (0, 0), (0, 1)).val()


def make_adjustable_wrench() -> Model:
    t = 15.5
    # One-piece body: handle, guide, bridge, and smooth fixed jaw.
    handle = poly_prism([
        (-203, -8), (-203, 8), (-48, 13), (-24, 18), (-4, 17),
        (4, 12), (4, -12), (-4, -17), (-24, -18), (-48, -13)
    ], t)
    vertical_guide = box(9, 53, t, -0.5, -8.5)
    upper_bridge = box(24, 10, t, 11, 19)
    fixed_jaw = poly_prism([(15, 20), (52, 20), (52, 38), (25, 38), (15, 32)], t)
    body = handle.fuse(vertical_guide).fuse(upper_bridge).fuse(fixed_jaw)

    # Moving jaw and rack: smooth horizontal contact face at y=8.
    moving_jaw = poly_prism([(10, 8), (52, 8), (52, -8), (29, -8), (18, -17), (5, -14), (5, 2)], t - 1.0)
    rack = box(10, 12, t - 1.0, 10, -13)
    moving = moving_jaw.fuse(rack)

    # Adjustment wheel tangent to, but not intersecting, the rack.
    worm = cq.Workplane("XY").center(12, -26.5).polygon(18, 15).extrude((t + 2) / 2, both=True).val()

    params = {
        "authoringUnits": "mm",
        "overallLengthMm": 255.0,
        "maxJawOpeningMm": 31.0,
        "displayJawOpeningMm": 12.0,
        "bodyThicknessMm": 15.5,
        "headEnvelopeWidthMm": 69.0,
        "wormDiameterMm": 15.0,
        "jawSurface": "smooth",
        "dimensionStatus": {
            "overallLengthMm": "corroborated product dimension",
            "maxJawOpeningMm": "corroborated product dimension",
            "bodyThicknessMm": "corroborated product dimension",
            "headEnvelopeWidthMm": "editorial closure",
            "displayJawOpeningMm": "editorial pose",
            "wormDiameterMm": "editorial closure"
        }
    }
    source_record = {
        "observationDate": OBS_DATE,
        "sourceClass": "C",
        "controllingGeometry": ["original project-authored B-rep"],
        "factReferences": [
            {
                "title": "ISO 6787:2018 Assembly tools for screws and nuts - Adjustable wrenches",
                "organization": "ISO",
                "url": "https://www.iso.org/standard/71911.html",
                "use": "functional type, terminology, test envelope; standard text not redistributed",
                "rights": "copyrighted standard; reference only"
            },
            {
                "title": "Bahco 8072 adjustable wrench product data",
                "organization": "Bahco/SNA Europe",
                "url": "https://www.bahco.com/int_en/ergotm-central-nut-adjustable-wrenches-with-rubber-handle-and-extra-wide-jaw-pb_80_series_.html",
                "use": "10-inch-class overall length, jaw opening, and thickness corroboration",
                "rights": "manufacturer page; facts reference only; no manufacturer asset reused"
            }
        ],
        "authoritativeOrCorroborated": ["smooth parallel gripping faces", "moving jaw", "worm adjustment", "selected principal dimensions"],
        "editorialOrInferred": ["body contour", "fillets", "guide form", "worm tooth form", "display opening"],
        "licenseOfNewGeometry": "CC0-1.0",
        "productionStatus": "prototype; human mechanical review required"
    }
    return Model(
        "t0004", "tool.adjustable-wrench", "Adjustable wrench",
        (Part("body-fixed-jaw", body), Part("moving-jaw-rack", moving), Part("worm-adjuster", worm)),
        params,
        {"three-quarter": (1.0, -1.1, 0.75), "profile": (0, 0, 1), "feature": (0.12, -0.18, 1)},
        ("body-fixed-jaw", "moving-jaw-rack", "worm-adjuster"),
        {
            "partCount": 3,
            "jawToothCount": 0,
            "jawFacesParallel": True,
            "wormPresent": True,
            "allowedIntersectionPairs": []
        },
        source_record
    )


def make_pipe_wrench() -> Model:
    t = 18.0
    handle = poly_prism([
        (-200, -10), (-200, 10), (-50, 14), (-22, 18), (2, 16),
        (10, 9), (8, -9), (0, -16), (-22, -18), (-50, -14)
    ], t)
    guide = box(9, 35, t, -19.5, 27.5)
    heel = poly_prism([(5, 8), (48, 8), (48, 24), (10, 24)], t)
    fixed_teeth = tooth_row(12, 44, 24.0, 3.5, 9, t, +1)
    body = handle.fuse(guide).fuse(heel).fuse(fixed_teeth)

    stem = box(9, 38, t - 1.0, 0, 37)
    hook = poly_prism([(0, 52), (14, 66), (50, 62), (49, 48), (12, 48)], t - 1.0)
    hook_teeth = tooth_row(13, 45, 48.0, 3.5, 9, t - 1.0, -1)
    hook_part = stem.fuse(hook).fuse(hook_teeth)

    # Collar/nut around the hook-jaw shank; axis follows shank travel (+Y).
    nut_outer = cq.Workplane("XZ").circle(14.0).extrude(5.0, both=True).translate((0, 36, 0)).val()
    nut_bore = cq.Workplane("XZ").circle(10.0).extrude(6.0, both=True).translate((0, 36, 0)).val()
    nut = nut_outer.cut(nut_bore)

    params = {
        "authoringUnits": "mm",
        "overallLengthMm": 250.0,
        "ratedPipeCapacityMm": 40.0,
        "displayJawOpeningMm": 20.0,
        "bodyThicknessMm": 18.0,
        "fixedJawTeeth": 9,
        "hookJawTeeth": 9,
        "jawSurface": "serrated",
        "dimensionStatus": {
            "overallLengthMm": "corroborated nominal product size",
            "ratedPipeCapacityMm": "corroborated product capacity",
            "displayJawOpeningMm": "editorial pose",
            "bodyThicknessMm": "editorial closure",
            "fixedJawTeeth": "editorial count; serration presence is controlling",
            "hookJawTeeth": "editorial count; serration presence is controlling"
        }
    }
    source_record = {
        "observationDate": OBS_DATE,
        "sourceClass": "C",
        "controllingGeometry": ["original project-authored B-rep"],
        "factReferences": [
            {
                "title": "Heavy-Duty Straight Pipe Wrenches",
                "organization": "RIDGID/Emerson",
                "url": "https://www.ridgid.com/us/en/straight-pipe-wrench",
                "use": "nominal size/capacity and component relationship corroboration",
                "rights": "manufacturer page; facts reference only; no manufacturer asset reused"
            },
            {
                "title": "Federal Specification GGG-W-651E, Wrenches, Pipe",
                "organization": "U.S. General Services Administration (cancelled specification)",
                "url": "https://quicksearch.dla.mil/qsDocDetails.aspx?ident_number=21236",
                "use": "historical public specification reference; not treated as current generic geometry",
                "rights": "government specification; document status/rights separately reviewed"
            }
        ],
        "authoritativeOrCorroborated": ["hook jaw", "fixed heel jaw", "serrated gripping surfaces", "adjusting nut", "selected nominal size/capacity"],
        "editorialOrInferred": ["body contour", "jaw tooth count/pitch", "guide form", "nut contour", "display opening"],
        "licenseOfNewGeometry": "CC0-1.0",
        "productionStatus": "prototype; human mechanical review required"
    }
    return Model(
        "t0005", "tool.pipe-wrench", "Pipe wrench",
        (Part("handle-fixed-heel-jaw", body), Part("hook-jaw-stem", hook_part), Part("adjusting-nut", nut)),
        params,
        {"three-quarter": (1.0, -1.1, 0.75), "profile": (0, 0, 1), "feature": (0.12, -0.18, 1)},
        ("handle-fixed-heel-jaw", "hook-jaw-stem", "adjusting-nut"),
        {
            "partCount": 3,
            "jawToothCount": 18,
            "hookJawPresent": True,
            "adjustingNutPresent": True,
            "allowedIntersectionPairs": []
        },
        source_record
    )


def make_cup_plunger() -> Model:
    cup_profile = [
        (66, 0), (68, 6), (65, 16), (55, 31), (39, 46), (18, 56), (12, 61),
        (8, 56), (18, 51), (34, 42), (49, 29), (58, 15), (60, 6), (58, 0)
    ]
    cup = revolved_shell(cup_profile)
    handle = cq.Workplane("XY").circle(10).extrude(475).translate((0, 0, 55)).val()
    params = {
        "authoringUnits": "mm",
        "overallHeightMm": 530.0,
        "cupOuterDiameterMm": 136.0,
        "handleDiameterMm": 20.0,
        "extendedFlangeHeightMm": 0.0,
        "dimensionStatus": {
            "overallHeightMm": "corroborated common product class",
            "cupOuterDiameterMm": "editorial closure",
            "handleDiameterMm": "editorial closure",
            "extendedFlangeHeightMm": "controlling categorical invariant"
        }
    }
    source_record = {
        "observationDate": OBS_DATE,
        "sourceClass": "C",
        "controllingGeometry": ["original project-authored revolved B-rep"],
        "factReferences": [
            {
                "title": "Cup plunger product category/reference",
                "organization": "multiple commercial manufacturers; category corroboration only",
                "url": "https://www.homedepot.com/p/HDX-5-in-Force-Cup-Plunger-BC2451-5/302785815",
                "use": "simple cup/no extended toilet flange and common size class",
                "rights": "retailer/manufacturer imagery reference only; no image reused"
            }
        ],
        "authoritativeOrCorroborated": ["simple flexible cup", "handle", "absence of extended toilet flange"],
        "editorialOrInferred": ["cup profile", "wall thickness", "handle attachment", "exact dimensions"],
        "licenseOfNewGeometry": "CC0-1.0",
        "productionStatus": "prototype; physical measurement or stronger dimensional source required"
    }
    return Model(
        "t0006", "tool.plunger.cup", "Cup plunger",
        (Part("simple-cup", cup), Part("handle", handle)),
        params,
        {"three-quarter": (1.0, -1.2, 0.45), "profile": (0, -1, 0), "feature": (0.8, -1.0, -0.18)},
        ("simple-cup",),
        {"partCount": 2, "extendedFlangePresent": False, "allowedIntersectionPairs": [["handle", "simple-cup"]]},
        source_record
    )


def make_flange_plunger() -> Model:
    cup_profile = [
        (75, 0), (77, 7), (73, 18), (62, 34), (44, 50), (19, 60), (13, 66),
        (9, 60), (20, 55), (39, 46), (55, 31), (66, 16), (68, 7), (65, 0)
    ]
    flange_profile = [(38, 2), (36, -14), (32, -45), (24, -45), (27, -14), (29, 2)]
    connector_profile = [(36, -1), (66, -1), (66, 3), (36, 3)]
    rubber = revolved_shell(cup_profile).fuse(revolved_shell(flange_profile)).fuse(revolved_shell(connector_profile))
    handle = cq.Workplane("XY").circle(12.7).extrude(549.6).translate((0, 0, 60)).val()
    params = {
        "authoringUnits": "mm",
        "overallHeightMm": 609.6,
        "cupOuterDiameterMm": 154.0,
        "handleDiameterMm": 25.4,
        "extendedFlangeHeightMm": 45.0,
        "dimensionStatus": {
            "overallHeightMm": "corroborated manufacturer dimension (24 in)",
            "cupOuterDiameterMm": "editorial closure",
            "handleDiameterMm": "corroborated manufacturer dimension (1 in)",
            "extendedFlangeHeightMm": "feature confirmed; exact height editorial"
        }
    }
    source_record = {
        "observationDate": OBS_DATE,
        "sourceClass": "C",
        "controllingGeometry": ["original project-authored revolved B-rep"],
        "factReferences": [
            {
                "title": "Premium Toilet Plunger #597",
                "organization": "Libman Commercial",
                "url": "https://libman.com/products/premium-toilet-plunger",
                "use": "extended flange, 24-inch total height, 1-inch handle class",
                "rights": "manufacturer page/catalog facts reference only; no image reused"
            }
        ],
        "authoritativeOrCorroborated": ["flexible cup", "extended flange beneath cup", "handle", "selected overall/handle dimensions"],
        "editorialOrInferred": ["cup and flange contour", "wall thickness", "attachment", "flange length"],
        "licenseOfNewGeometry": "CC0-1.0",
        "productionStatus": "prototype; physical measurement or stronger dimensional source required"
    }
    return Model(
        "t0007", "tool.plunger.flange", "Flange plunger",
        (Part("cup-with-extended-flange", rubber), Part("handle", handle)),
        params,
        {"three-quarter": (1.0, -1.2, 0.45), "profile": (0, -1, 0), "feature": (0.8, -1.0, -0.24)},
        ("cup-with-extended-flange",),
        {"partCount": 2, "extendedFlangePresent": True, "extendedFlangeMinHeightMm": 40.0, "allowedIntersectionPairs": [["cup-with-extended-flange", "handle"]]},
        source_record
    )


def normalize_step(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    text = re.sub(r"(FILE_NAME\('[^']*',')[^']*(')", rf"\g<1>{FIXED_TIMESTAMP}\2", text, count=1)
    # Remove output path variability from FILE_NAME first parameter.
    text = re.sub(r"FILE_NAME\('[^']*'", "FILE_NAME('master.step'", text, count=1)
    path.write_text(text.replace("\r\n", "\n"), encoding="utf-8", newline="\n")


def export_svg(shape: cq.Shape, path: Path, direction: tuple[float, float, float]) -> None:
    exporters.export(shape, str(path), exportType="SVG", opt={
        "projectionDir": direction,
        "showHidden": False,
        "strokeWidth": 0.45,
        "showAxes": False,
        "width": 1600,
        "height": 1600,
        "marginLeft": 35,
        "marginTop": 35,
    })
    text = path.read_text(encoding="utf-8")
    # White background, black lines, deterministic style; hidden lines are absent.
    insert_at = text.find(">", text.find("<svg")) + 1
    text = text[:insert_at] + '\n<rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF"/>\n' + text[insert_at:]
    text = text.replace('stroke="rgb(0,0,0)" fill="none"', 'stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"')
    text = text.replace('stroke="rgb(160,160,160)"', 'stroke="#FFFFFF"')
    text = "\n".join(line.rstrip() for line in text.replace("\r\n", "\n").splitlines()) + "\n"
    path.write_text(text, encoding="utf-8", newline="\n")


def rasterize(svg: Path, png: Path, webp: Path) -> None:
    cairosvg.svg2png(url=str(svg), write_to=str(png), output_width=2048, output_height=2048, background_color="#FFFFFF")
    with Image.open(png) as im:
        im = im.convert("L")
        im.save(webp, "WEBP", lossless=True, method=6)


def export_glb(model: Model, part_dir: Path, out_path: Path) -> None:
    scene = trimesh.Scene()
    # CAD mm, right-handed, +Z up -> glTF meters, right-handed, +Y up.
    xform = np.array([
        [0.001, 0, 0, 0],
        [0, 0, 0.001, 0],
        [0, -0.001, 0, 0],
        [0, 0, 0, 1],
    ], dtype=float)
    for i, _part in enumerate(model.parts, 1):
        stl = part_dir / f"part-{i:03d}.stl"
        mesh = trimesh.load_mesh(stl, process=True, maintain_order=False)
        if isinstance(mesh, trimesh.Scene):
            mesh = trimesh.util.concatenate(tuple(mesh.geometry.values()))
        mesh.merge_vertices()
        mesh.remove_unreferenced_vertices()
        mesh.apply_transform(xform)
        mesh.metadata.clear()
        mesh.visual = trimesh.visual.ColorVisuals(mesh=mesh, face_colors=[210, 210, 210, 255])
        scene.add_geometry(mesh, node_name=f"part-{i:03d}", geom_name=f"mesh-{i:03d}")
    scene.metadata.clear()
    out_path.write_bytes(trimesh.exchange.gltf.export_glb(scene, include_normals=True))


def glb_json_chunk(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    if data[:4] != b"glTF":
        raise ValueError("not GLB")
    _, _, total = struct.unpack_from("<III", data, 0)
    if total != len(data):
        raise ValueError("invalid GLB length")
    chunk_len, chunk_type = struct.unpack_from("<II", data, 12)
    if chunk_type != 0x4E4F534A:
        raise ValueError("missing JSON chunk")
    raw = data[20:20 + chunk_len].rstrip(b" \x00")
    return json.loads(raw.decode("utf-8"))


def bbox(shape: cq.Shape) -> dict[str, float]:
    b = shape.BoundingBox()
    return {k: round(float(v), 6) for k, v in {
        "xmin": b.xmin, "xmax": b.xmax, "xlen": b.xlen,
        "ymin": b.ymin, "ymax": b.ymax, "ylen": b.ylen,
        "zmin": b.zmin, "zmax": b.zmax, "zlen": b.zlen,
    }.items()}


def mesh_metrics(path: Path) -> dict[str, Any]:
    mesh = trimesh.load_mesh(path, process=True, maintain_order=False)
    if isinstance(mesh, trimesh.Scene):
        mesh = trimesh.util.concatenate(tuple(mesh.geometry.values()))
    mesh.merge_vertices()
    mesh.remove_unreferenced_vertices()
    comps = mesh.split(only_watertight=False)
    return {
        "vertices": int(len(mesh.vertices)),
        "faces": int(len(mesh.faces)),
        "connectedComponents": int(len(comps)),
        "watertight": bool(mesh.is_watertight),
        "windingConsistent": bool(mesh.is_winding_consistent),
        "volumeMm3": round(abs(float(mesh.volume)), 6),
    }


def render_mask(path: Path) -> np.ndarray:
    arr = np.asarray(Image.open(path).convert("L"))
    edge = arr < 180
    edge = ndimage.binary_dilation(edge, iterations=2)
    return ndimage.binary_fill_holes(edge)


def iou(a: Path, b: Path) -> float:
    ma, mb = render_mask(a), render_mask(b)
    inter = np.logical_and(ma, mb).sum()
    union = np.logical_or(ma, mb).sum()
    return round(float(inter / union), 6) if union else 1.0


def build_model(model: Model, root: Path) -> dict[str, Any]:
    od = root / "objects" / model.asset_key
    for d in ["source", "master", "web", "renders", "mesh-parts", "qa"]:
        (od / d).mkdir(parents=True, exist_ok=True)
    json_write(od / "source" / "parameters.json", model.params)
    source_record = json.loads(json.dumps(model.source_record))
    for ref in source_record.get("factReferences", []):
        ref.setdefault("sourceFileSha256", None)
        ref.setdefault("sourceFileHashStatus", "not downloaded or not redistributed; reference-only web/document source")
    json_write(od / "source" / "source-record.json", source_record)

    step = od / "master" / "master.step"
    exporters.export(model.compound, str(step), exportType="STEP")
    normalize_step(step)
    stl = od / "master" / "review-mesh.stl"
    exporters.export(model.compound, str(stl), exportType="STL", tolerance=0.08, angularTolerance=0.08)
    for i, part in enumerate(model.parts, 1):
        exporters.export(part.shape, str(od / "mesh-parts" / f"part-{i:03d}.stl"), exportType="STL", tolerance=0.08, angularTolerance=0.08)
    glb = od / "web" / "model.glb"
    export_glb(model, od / "mesh-parts", glb)

    rendered: list[Path] = []
    feature_shapes = [p.shape for p in model.parts if p.private_name in model.feature_parts]
    feature_compound = cq.Compound.makeCompound(feature_shapes)
    for view, direction in model.views.items():
        target = feature_compound if view == "feature" else model.compound
        svg = od / "renders" / f"{view}.svg"
        png = od / "renders" / f"{view}.png"
        webp = od / "renders" / f"{view}.webp"
        export_svg(target, svg, direction)
        rasterize(svg, png, webp)
        rendered += [svg, png, webp]

    allowed = {tuple(sorted(x)) for x in model.expected.get("allowedIntersectionPairs", [])}
    intersections = []
    for i, pa in enumerate(model.parts):
        for pb in model.parts[i + 1:]:
            pair = tuple(sorted((pa.private_name, pb.private_name)))
            vol = abs(float(pa.shape.intersect(pb.shape).Volume()))
            permitted = pair in allowed
            intersections.append({
                "partsPrivateBuildMetadata": list(pair),
                "intersectionVolumeMm3": round(vol, 6),
                "allowedMechanicalEngagement": permitted,
                "pass": permitted or vol <= 0.01,
            })

    part_results = []
    for i, part in enumerate(model.parts, 1):
        part_results.append({
            "partIndex": i,
            "privateName": part.private_name,
            "brepValid": bool(part.shape.isValid()),
            "bboxMm": bbox(part.shape),
            **mesh_metrics(od / "mesh-parts" / f"part-{i:03d}.stl"),
        })

    glb_json = glb_json_chunk(glb)
    leak_text = json.dumps(glb_json, sort_keys=True).lower()
    forbidden = [model.canonical_term.lower(), model.taxonomy_id.lower(), "adjustable", "pipe wrench", "plunger", "cup plunger", "flange plunger"]
    leak_hits = sorted({x for x in forbidden if x in leak_text})

    output_paths = [step, stl, glb, *rendered]
    validation = {
        "assetKey": model.asset_key,
        "taxonomyIdPrivateBuildMetadata": model.taxonomy_id,
        "observationDate": OBS_DATE,
        "compoundBrepValid": bool(model.compound.isValid()),
        "compoundBboxMm": bbox(model.compound),
        "expected": model.expected,
        "partResults": part_results,
        "pairwiseIntersections": intersections,
        "metadataLeakScan": {"forbiddenHits": leak_hits, "pass": not leak_hits},
        "checks": {
            "partCountMatches": len(model.parts) == model.expected["partCount"],
            "allPartsBrepValid": all(x["brepValid"] for x in part_results),
            "allPartMeshesWatertight": all(x["watertight"] for x in part_results),
            "noUnexpectedIntersection": all(x["pass"] for x in intersections),
            "unitsAreMm": model.params.get("authoringUnits") == "mm",
            "deliveryMetadataNeutral": not leak_hits,
        },
        "outputSha256": {str(p.relative_to(root)): sha256(p) for p in sorted(output_paths)},
    }
    json_write(od / "qa" / "validation.json", validation)
    json_write(od / "qa" / "manual-checklist.json", {
        "status": "PENDING_HUMAN_MECHANICAL_REVIEW",
        "reviewer": None,
        "reviewDate": None,
        "checklist": [
            "Must-have components are visible and mechanically connected or guided.",
            "No prohibited component, logo, watermark, or trade dress is present.",
            "Moving parts have coherent axes/guides and no unexplained intersections.",
            "Pair distinction survives monochrome rendering at intended display size.",
            "Every dimension labelled corroborated matches its cited source.",
            "Every unsourced contour remains labelled editorial/inferred.",
            "Scored delivery paths, node names, extras, accessible names, and URLs reveal no answer.",
            "The candidate does not imitate an official exam drawing."
        ]
    })
    return validation


def create_preview(root: Path, models: list[Model]) -> Path:
    views = ["three-quarter", "profile", "feature"]
    thumb = 520
    label_h = 38
    margin = 18
    canvas = Image.new("RGB", (len(views) * (thumb + margin) + margin, len(models) * (thumb + label_h + margin) + margin), "white")
    draw = ImageDraw.Draw(canvas)
    for r, model in enumerate(models):
        for c, view in enumerate(views):
            im = Image.open(root / "objects" / model.asset_key / "renders" / f"{view}.png").convert("RGB")
            im = ImageOps.contain(im, (thumb, thumb))
            x = margin + c * (thumb + margin)
            y = margin + r * (thumb + label_h + margin)
            draw.text((x, y + 8), f"{model.asset_key} {view}", fill="black")
            py = y + label_h
            canvas.paste(im, (x + (thumb - im.width) // 2, py + (thumb - im.height) // 2))
    path = root / "poc-preview.png"
    canvas.save(path)
    return path


def write_manifest(root: Path, models: list[Model], validations: dict[str, Any]) -> None:
    assets = []
    for model in models:
        assets.append({
            "taxonomyId": model.taxonomy_id,
            "assetId": model.asset_key,
            "assetVersion": "0.1.0-poc",
            "canonicalTerm": model.canonical_term,
            "sourceClass": "C",
            "status": "prototype-not-production-approved",
            "sourceUrls": [x["url"] for x in model.source_record["factReferences"]],
            "accessDates": [OBS_DATE],
            "authoringUnits": "mm",
            "coordinateConvention": {
                "authoringHandedness": "right-handed",
                "authoringUp": "+Z",
                "webHandedness": "right-handed",
                "webUp": "+Y",
                "webUnits": "m",
                "webTransform": "(x,y,z)_mm -> (x,z,-y)_m"
            },
            "sourceModelPath": f"objects/{model.asset_key}/master/master.step",
            "derivedGlbPath": f"objects/{model.asset_key}/web/model.glb",
            "derivedStaticRenderPaths": [f"objects/{model.asset_key}/renders/{view}.{ext}" for view in model.views for ext in ("svg", "png", "webp")],
            "renderConfiguration": {
                "projection": "orthographic hidden-line removal",
                "background": "#FFFFFF",
                "stroke": "#000000",
                "hatching": "none in POC",
                "views": {k: list(v) for k, v in model.views.items()},
                "svgCanvasPx": [1600, 1600],
                "pngCanvasPx": [2048, 2048]
            },
            "toolchain": {
                "python": "3.13.5",
                "cadquery": "2.8.0",
                "ocpOcct": "7.9.3.1",
                "trimesh": "4.11.1",
                "numpy": "2.3.5",
                "scipy": "1.17.0",
                "pillow": "12.3.0",
                "cairoSvg": "2.8.2",
                "controlledPlatform": "Linux x86_64; glibc 2.41",
                "sourceDateEpoch": SOURCE_DATE_EPOCH
            },
            "outputHashes": validations[model.asset_key]["outputSha256"],
            "mechanicalQaStatus": "pending-human-review",
            "rightsQaStatus": "newly-authored-geometry; external facts only",
            "scoredPageMetadataLeakReview": {
                "deliveryFilenameNeutral": True,
                "glbNodeNamesNeutral": True,
                "glbExtrasScrubbed": True,
                "automaticScan": validations[model.asset_key]["metadataLeakScan"],
                "status": "automated-pass" if validations[model.asset_key]["metadataLeakScan"]["pass"] else "automated-fail"
            }
        })
    json_write(root / "manifest.poc.json", {"schemaVersion": "0.1.0-poc", "assets": assets})


def write_readme(root: Path) -> None:
    root.joinpath("README.md").write_text(f"""# Deterministic tool-illustration POC

Observation date: {OBS_DATE}

This read-only research artifact was created outside the repository. It contains no third-party geometry, images, textures, logos, or official exam artwork.

Objects:
- `t0004`: adjustable wrench
- `t0005`: pipe wrench
- `t0006`: cup plunger
- `t0007`: flange plunger

The descriptive mapping exists only in private build metadata. Web-delivery filenames and GLB node names are neutral.

## Reproduction

```sh
export SOURCE_DATE_EPOCH={SOURCE_DATE_EPOCH}
python build_poc.py --out ./build-a
python build_poc.py --out ./build-b
python compare_builds.py ./build-a ./build-b
```

The build performs no network access. The controlled platform is documented in `build-environment.json`.

## Acceptance status

This is a pipeline proof, not a production geometry approval. Automated B-rep, mesh, intersection, output-hash, and metadata-leak results are under each object's `qa/` directory. Human mechanical and rights review remains mandatory. Unconstrained contours are explicitly marked editorial in each `source-record.json`.

## Rights

Newly authored POC geometry and scripts are dedicated under CC0-1.0 for this research artifact. External standards and manufacturer pages are factual references only and are not redistributed.
""", encoding="ascii", newline="\n")


def write_hashes(root: Path) -> None:
    paths = [p for p in root.rglob("*") if p.is_file() and p.name != "SHA256SUMS"]
    root.joinpath("SHA256SUMS").write_text("\n".join(f"{sha256(p)}  {p.relative_to(root).as_posix()}" for p in sorted(paths)) + "\n", encoding="ascii", newline="\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    root = args.out.resolve()
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    os.environ["SOURCE_DATE_EPOCH"] = SOURCE_DATE_EPOCH

    models = [make_adjustable_wrench(), make_pipe_wrench(), make_cup_plunger(), make_flange_plunger()]
    validations = {m.asset_key: build_model(m, root) for m in models}
    pair_qa = {
        "observationDate": OBS_DATE,
        "pairs": [
            {
                "pairId": "pair.wrench.adjustable-pipe",
                "profileSilhouetteIoUAutofitDiagnostic": iou(root / "objects/t0004/renders/profile.png", root / "objects/t0005/renders/profile.png"),
                "featureSilhouetteIoUAutofitDiagnostic": iou(root / "objects/t0004/renders/feature.png", root / "objects/t0005/renders/feature.png"),
            },
            {
                "pairId": "pair.plunger.cup-flange",
                "profileSilhouetteIoUAutofitDiagnostic": iou(root / "objects/t0006/renders/profile.png", root / "objects/t0007/renders/profile.png"),
                "featureSilhouetteIoUAutofitDiagnostic": iou(root / "objects/t0006/renders/feature.png", root / "objects/t0007/renders/feature.png"),
            }
        ],
        "interpretation": "IoU is diagnostic only. Mechanical feature/keypoint review remains controlling."
    }
    json_write(root / "qa" / "pair-comparison.json", pair_qa)
    write_manifest(root, models, validations)
    json_write(root / "build-environment.json", {
        "observationDate": OBS_DATE,
        "sourceDateEpoch": SOURCE_DATE_EPOCH,
        "platform": "Linux-6.18.35-x86_64-with-glibc2.41",
        "python": "3.13.5",
        "packages": {"cadquery": "2.8.0", "OCP": "7.9.3.1", "trimesh": "4.11.1", "numpy": "2.3.5", "scipy": "1.17.0", "Pillow": "12.3.0", "CairoSVG": "2.8.2"},
        "networkRequired": False
    })
    create_preview(root, models)
    write_readme(root)
    write_hashes(root)
    print(root)


if __name__ == "__main__":
    main()
