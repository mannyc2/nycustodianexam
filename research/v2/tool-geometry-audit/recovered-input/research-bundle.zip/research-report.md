# Deterministic, Mechanically Accurate Tool Illustration Pipeline

- Observation date: 2026-08-20
- Repository: `mannyc2/nycustodianexam`
- Immutable base: `92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c`
- Authorization: read-only research; no repository branch, files, commits, packages, application framework, or production assets were created.
- Evidence labels: Confirmed = primary source directly supports; Corroborated = multiple sources agree; Inferred = analytical conclusion; Not located = adequate evidence was not found.

The branch verification matched the required SHA. The canonical repository documents were then read at that exact commit [C-BASE, C-AGENTS, C-TAXONOMY, C-LANDSCAPE, C-OPEN, C-SCOPE; observed 2026-08-20].

## 1. Executive verdict

**Verdict: no single standard, classification system, CAD portal, or open 3D dataset provides complete, rights-cleared, mechanically trustworthy generic geometry for a useful majority of the 65 normalized Tier A/B illustration concepts.** Hand-tool standards constrain terminology, principal dimensions, performance, and tests for a narrow subset; ETIM/ECLASS describe classes and attributes; STEP/glTF/IFC are interchange or delivery formats; open collections remain per-object licensing and mechanical-review problems [S-ISO6787, S-ASME107100, S-ASME107400, S-ASME107500, D-ETIM10, D-ETIMMC2, D-ECLASS16, F-STEP242, F-IFC, F-GLTF, DS-GSO, DS-ABO, DS-OBJAVERSE, DS-POLYHAVEN; observed 2026-08-20].

The primary architecture should therefore be:

```text
cited facts, dimensions, and documented measurements
  -> versioned JSON parameter/evidence record
  -> project-authored CadQuery/OCCT B-rep
  -> automated geometry and invariant validation
  -> normalized STEP AP242 review/interchange master
  -> derived neutral GLB for optional atlas use
  -> OCCT hidden-line orthographic SVG views
  -> deterministic PNG/WebP derivatives
  -> manifest, hashes, rights record, mechanical QA, accessibility, and leak review
```

This is an Inferred architectural recommendation based on the source and POC results. The authoring source is code plus parameter/evidence records; STEP is the neutral review/interchange master; GLB is never the geometry-authority source.

Operational answers to the seven objective questions:

1. **Useful standards/data combination?** Yes, but only as a partial evidence layer. ISO/ASME/ANSI cover selected wrenches, pliers, striking tools, and ladders; product-data systems can help with naming/attributes; manufacturer and government specifications can contribute product-specific or historical dimensions. No combination found supplies full generic geometry across the taxonomy [Confirmed/Not located; standards matrix below].
2. **Can it generate mechanically correct generic 3D automatically?** No. Principal dimensions leave body contours, wall thicknesses, fasteners, guides, tooth form, tolerances, and articulation details undefined. Human-authored closure based on multiple references or physical measurement is unavoidable [Inferred from standards scopes and POC].
3. **Canonical format/pipeline?** JSON evidence/parameters plus CadQuery Python as source, OCCT B-rep as geometry kernel, normalized STEP AP242 as neutral master, GLB and SVG/PNG/WebP as derived outputs [Inferred].
4. **Static or interactive?** Static line art is controlling everywhere. Interactive 3D is optional and user-invoked on atlas/reference pages only [Inferred; C-TAXONOMY, C-LANDSCAPE, C-SCOPE].
5. **Image generation?** Do not use it in production. A narrow local, immutable, fixed-seed experiment may be run only after a verified deterministic render, with automatic rejection for any geometry change. The expected value does not justify the added risk for this monochrome style [Inferred].
6. **Fallback?** Original multi-view photography and physical measurement, followed by a Class C deterministic model or a Class D deterministic 2D transform. If rights or geometry remain inadequate, assign Class F and publish no illustration [Inferred].
7. **Verification?** Per-dimension provenance, exact license fields, source/output SHA-256, B-rep validity, watertight meshes, component/intersection tests, invariant/keypoint checks, silhouette/edge regression, metadata leak scans, and independent human mechanical/rights review [Inferred; POC].

Current sourcing disposition after this pass: 0 Class A, 0 accepted Class B, 4 Class C proof models pending human review, 0 accepted Class D, 16 Class E priority references, and 45 Class F unaudited/blocked concepts. No production asset is approved by this report.

## 2. Taxonomy geometry inventory

The canonical taxonomy contains 67 Tier A/B-containing heading records. One `Staple gun` heading is duplicated, and the official-sample `Protective gloves` node overlaps the later generic chemical/protective-gloves node. Normalizing those into illustration concepts yields 65 unique assets [Confirmed; C-TAXONOMY; observed 2026-08-20]. The stable IDs below are editorial proposals, not existing canonical IDs.

| Family | Count |
| --- | --- |
| rigid hand tools | 15 |
| articulated hand tools | 12 |
| cleaning implements | 10 |
| soft or deformable tools | 7 |
| powered cleaning equipment | 8 |
| ladders/access equipment | 2 |
| carts/material-handling equipment | 4 |
| PPE | 3 |
| other | 4 |

Family assignment is exclusive for planning: specialized powered/ladders/cart/PPE/soft categories take precedence; articulated means pose-dependent geometry or an exposed adjustment mechanism; rigid means no pose-dependent geometry in the canonical view. This is editorial geometry planning, not an exam classification.

### Complete normalized inventory

| ID | Canonical term | Tier | Visual family | Confusable IDs | Current class/status |
| --- | --- | --- | --- | --- | --- |
| tool.scrub-brush | Scrub brush | A | cleaning implements | - | E / reference-only |
| tool.staple-gun | Staple gun | A | articulated hand tools | - | E / reference-only |
| ppe.protective-gloves | Protective gloves (generic) | A/A-B overlap | PPE | - | E / reference-only |
| tool.push-broom | Push broom | B | cleaning implements | tool.deck-brush | E / reference-only |
| tool.angle-broom | Angle broom / household broom | B | cleaning implements | - | F / blocked-not-audited |
| tool.dust-mop | Dust mop | B | soft or deformable tools | tool.wet-mop | F / blocked-not-audited |
| tool.wet-mop | Wet/string mop | B | soft or deformable tools | tool.dust-mop | F / blocked-not-audited |
| tool.flat-mop | Flat mop | B | soft or deformable tools | - | F / blocked-not-audited |
| equipment.mop-bucket-wringer | Mop bucket and wringer | B | carts/material-handling equipment | - | F / blocked-not-audited |
| tool.deck-brush | Deck brush | B | cleaning implements | tool.push-broom | E / reference-only |
| tool.hand-scrub-brush | Hand scrub brush | A/B | cleaning implements | - | F / blocked-not-audited |
| tool.toilet-bowl-brush | Toilet bowl brush | B | cleaning implements | - | F / blocked-not-audited |
| tool.duster | Duster / feather or synthetic duster | B | soft or deformable tools | - | F / blocked-not-audited |
| tool.dustpan | Dustpan | B | cleaning implements | - | F / blocked-not-audited |
| tool.floor-squeegee | Floor squeegee | B | cleaning implements | tool.window-squeegee | F / blocked-not-audited |
| tool.window-squeegee | Window squeegee | B | cleaning implements | tool.floor-squeegee | F / blocked-not-audited |
| tool.window-strip-washer | Window washer / strip washer | B | cleaning implements | - | F / blocked-not-audited |
| equipment.janitor-cart | Janitor cart | B | carts/material-handling equipment | - | F / blocked-not-audited |
| equipment.hand-truck | Hand truck | B | carts/material-handling equipment | - | F / blocked-not-audited |
| equipment.dolly | Equipment dolly | B | carts/material-handling equipment | - | F / blocked-not-audited |
| equipment.vacuum.upright | Upright vacuum | B | powered cleaning equipment | equipment.carpet-extractor | F / blocked-not-audited |
| equipment.vacuum.canister | Canister vacuum | B | powered cleaning equipment | - | F / blocked-not-audited |
| equipment.vacuum.wet-dry | Wet/dry vacuum | B | powered cleaning equipment | - | F / blocked-not-audited |
| equipment.carpet-extractor | Carpet extractor | B | powered cleaning equipment | equipment.vacuum.upright | F / blocked-not-audited |
| equipment.steam-cleaner | Steam-cleaning equipment | B | powered cleaning equipment | - | F / blocked-not-audited |
| equipment.floor-machine.low-speed | Low-speed rotary floor machine | B | powered cleaning equipment | equipment.burnisher.high-speed | E / reference-only |
| equipment.burnisher.high-speed | High-speed burnisher | B | powered cleaning equipment | equipment.floor-machine.low-speed | E / reference-only |
| equipment.vacuum.ride-on | Ride-on industrial vacuum cleaner | B/C | powered cleaning equipment | - | F / blocked-not-audited |
| equipment.snow-blower | Snow blower | B/C | other | - | F / blocked-not-audited |
| equipment.hedge-trimmer | Hedge trimmer | B/C | other | - | F / blocked-not-audited |
| tool.hammer.claw | Claw hammer | B | rigid hand tools | tool.hammer.ball-peen | E / reference-only |
| tool.hammer.ball-peen | Ball-peen hammer | B | rigid hand tools | tool.hammer.claw | E / reference-only |
| tool.mallet.rubber | Rubber mallet | B | rigid hand tools | - | F / blocked-not-audited |
| tool.screwdriver.slotted | Flat/slotted screwdriver | B | rigid hand tools | - | F / blocked-not-audited |
| tool.screwdriver.phillips | Phillips screwdriver | B | rigid hand tools | - | F / blocked-not-audited |
| tool.adjustable-wrench | Adjustable wrench | B | articulated hand tools | tool.pipe-wrench | C / prototype-not-approved |
| tool.pipe-wrench | Pipe wrench | B | articulated hand tools | tool.adjustable-wrench | C / prototype-not-approved |
| tool.wrench.fixed | Combination/open-end/box wrench | B | rigid hand tools | - | F / blocked-not-audited |
| tool.pliers.slip-joint | Slip-joint pliers | B | articulated hand tools | tool.pliers.tongue-groove | E / reference-only |
| tool.pliers.tongue-groove | Tongue-and-groove pliers | B | articulated hand tools | tool.pliers.slip-joint | E / reference-only |
| tool.pliers.needle-nose | Needle-nose pliers | B | articulated hand tools | tool.pliers.diagonal-cutting | E / reference-only |
| tool.pliers.diagonal-cutting | Diagonal cutting pliers | B | articulated hand tools | tool.pliers.needle-nose | E / reference-only |
| tool.pliers.locking | Locking pliers | B | articulated hand tools | tool.clamp.c | F / blocked-not-audited |
| tool.clamp.c | C-clamp | B | articulated hand tools | tool.pliers.locking\|tool.clamp.bar | F / blocked-not-audited |
| tool.clamp.bar | Bar clamp | B | articulated hand tools | tool.clamp.c | F / blocked-not-audited |
| tool.hand-plane | Hand plane | A/B | rigid hand tools | - | E / reference-only |
| tool.saw.crosscut | Crosscut saw | B | rigid hand tools | tool.saw.rip | F / blocked-not-audited |
| tool.saw.rip | Rip saw | B | rigid hand tools | tool.saw.crosscut | F / blocked-not-audited |
| tool.saw.hacksaw | Hacksaw | B | rigid hand tools | - | F / blocked-not-audited |
| tool.utility-knife | Utility knife | B | articulated hand tools | - | F / blocked-not-audited |
| tool.putty-knife | Putty knife | B | rigid hand tools | tool.paint-scraper | F / blocked-not-audited |
| tool.paint-scraper | Paint scraper | B | rigid hand tools | tool.putty-knife | F / blocked-not-audited |
| tool.tape-measure | Tape measure | B | articulated hand tools | - | F / blocked-not-audited |
| tool.level | Level | B | rigid hand tools | - | F / blocked-not-audited |
| tool.square | Carpenter square / combination square | B | rigid hand tools | - | F / blocked-not-audited |
| tool.plunger.cup | Plunger - cup | B | soft or deformable tools | tool.plunger.flange | C / prototype-not-approved |
| tool.plunger.flange | Plunger - flange | B | soft or deformable tools | tool.plunger.cup | C / prototype-not-approved |
| tool.drain-snake | Hand auger / drain snake | B/C | soft or deformable tools | - | F / blocked-not-audited |
| tool.pipe-reamer | Pipe reamer | B/C | rigid hand tools | - | F / blocked-not-audited |
| tool.soldering-gun | Soldering gun | A visual/C operational | other | - | F / blocked-not-audited |
| access.stepladder | Stepladder | B | ladders/access equipment | access.extension-ladder | E / reference-only |
| access.extension-ladder | Extension ladder | B | ladders/access equipment | access.stepladder | E / reference-only |
| ppe.safety-glasses | Safety glasses | B | PPE | - | F / blocked-not-audited |
| ppe.ear-plugs | Protective ear plugs | B | PPE | - | F / blocked-not-audited |
| safety.wet-floor-sign | Wet-floor warning sign/cone | B | other | - | F / blocked-not-audited |

### Confusable-pair registry

| Pair ID | Left | Right |
| --- | --- | --- |
| pair.floor-machine-burnisher | equipment.floor-machine.low-speed | equipment.burnisher.high-speed |
| pair.pipe-adjustable-wrench | tool.pipe-wrench | tool.adjustable-wrench |
| pair.cup-flange-plunger | tool.plunger.cup | tool.plunger.flange |
| pair.crosscut-rip-saw | tool.saw.crosscut | tool.saw.rip |
| pair.claw-ball-peen | tool.hammer.claw | tool.hammer.ball-peen |
| pair.step-extension-ladder | access.stepladder | access.extension-ladder |
| pair.dust-wet-mop | tool.dust-mop | tool.wet-mop |
| pair.floor-window-squeegee | tool.floor-squeegee | tool.window-squeegee |
| pair.upright-vac-extractor | equipment.vacuum.upright | equipment.carpet-extractor |
| pair.slip-tongue-pliers | tool.pliers.slip-joint | tool.pliers.tongue-groove |
| pair.needle-diagonal-pliers | tool.pliers.needle-nose | tool.pliers.diagonal-cutting |
| pair.putty-scraper | tool.putty-knife | tool.paint-scraper |
| pair.cclamp-locking-bar | tool.clamp.c | tool.pliers.locking\|tool.clamp.bar |
| pair.push-deck-brush | tool.push-broom | tool.deck-brush |

These pairs are editorial learning structures, not official DCS pairs [Confirmed; C-TAXONOMY, C-OPEN; observed 2026-08-20].

### First 20 priority assets

| Rank | ID | Term | Current class | Planned class | Rationale |
| --- | --- | --- | --- | --- | --- |
| 1 | tool.scrub-brush | Scrub brush | E | C | Official sample concept; immediate visual-recognition value. |
| 2 | tool.staple-gun | Staple gun | E | C | Official sample concept; immediate visual-recognition value. |
| 3 | ppe.protective-gloves | Protective gloves (generic) | E | D | Official sample concept; immediate visual-recognition value. |
| 4 | tool.adjustable-wrench | Adjustable wrench | C | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 5 | tool.pipe-wrench | Pipe wrench | C | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 6 | tool.plunger.cup | Plunger - cup | C | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 7 | tool.plunger.flange | Plunger - flange | C | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 8 | access.stepladder | Stepladder | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 9 | access.extension-ladder | Extension ladder | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 10 | tool.hammer.claw | Claw hammer | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 11 | tool.hammer.ball-peen | Ball-peen hammer | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 12 | tool.pliers.slip-joint | Slip-joint pliers | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 13 | tool.pliers.tongue-groove | Tongue-and-groove pliers | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 14 | tool.pliers.needle-nose | Needle-nose pliers | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 15 | tool.pliers.diagonal-cutting | Diagonal cutting pliers | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 16 | tool.push-broom | Push broom | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 17 | tool.deck-brush | Deck brush | E | C | Current confusable pair with large visible functional distinction and/or relevant standards. |
| 18 | equipment.floor-machine.low-speed | Low-speed rotary floor machine | E | F | High-value pair, but intentionally placed in tranche as a blocked research case rather than a forced asset. |
| 19 | equipment.burnisher.high-speed | High-speed burnisher | E | F | High-value pair, but intentionally placed in tranche as a blocked research case rather than a forced asset. |
| 20 | tool.hand-plane | Hand plane | E | C | Official distractor relevance and CAD-friendly rigid form. |

### Visual-invariant sheets

#### 1. `tool.scrub-brush` - Scrub brush

- Must-have visible components: A brush body/block and a dense field of bristles; a hand grip or long handle only when the selected subtype declares it.
- Must-not-have components: No toilet-bowl-specific curved stem/head, window sleeve, squeegee blade, or broad broom-like sweeping head.
- Mechanically necessary relationships: Bristles must be rooted in the block and project toward the work surface; any handle must be mechanically joined to the block.
- Permitted real-world variation: Hand scrub brush and long-handle scrub brush are valid variants but must not be silently mixed in one canonical asset.
- Distinguishing features: Short, stiff scrubbing bristles and a compact block versus a broad push-broom head; subtype label needed versus deck brush.
- Articulation/moving parts: None for ordinary fixed-handle examples.
- Soft/deformable components: Bristle bundle is deformable; body/handle are rigid.
- Real-world scale: Medium. Pair framing must not imply that hand and long-handle variants are the same size.
- Minimum useful views: Profile plus 3/4; underside/bristle view if the distinction depends on bristle field.
- Ambiguity risk: The canonical term is broad. The repo contains both Scrub brush and Hand scrub brush, so subtype governance is required.
- Evidence: C-TAXONOMY; P-LIBMAN-SCRUB; observed 2026-08-20. Editorial display choices are identified as such above.

#### 2. `tool.staple-gun` - Staple gun

- Must-have visible components: Body, staple magazine/channel, staple-driving nose, and an actuating lever/trigger appropriate to the declared manual subtype.
- Must-not-have components: No soldering tip, heating element, plane iron/sole, clamp screw, invented cord, or pneumatic fitting unless that subtype is explicit.
- Mechanically necessary relationships: Lever pivots over the body; magazine feeds toward the nose; the nose is at the staple exit.
- Permitted real-world variation: Manual, electric, and pneumatic forms exist. The first asset should be a generic manual lever type because the official concept is visual recognition, not power-source trivia.
- Distinguishing features: Magazine and driving nose plus top lever, rather than a soldering-gun tip or clamp jaw.
- Articulation/moving parts: Lever pivot; magazine latch may move but need not be animated.
- Soft/deformable components: Optional grip cover only.
- Real-world scale: Low to medium; proportions matter more than absolute size.
- Minimum useful views: Side/profile, 3/4, and nose/magazine feature view.
- Ambiguity risk: Brand trade dress and accidental electric/pneumatic features.
- Evidence: C-TAXONOMY; P-ARROW-T50; observed 2026-08-20. Editorial display choices are identified as such above.

#### 3. `ppe.protective-gloves` - Protective gloves

- Must-have visible components: A hand-covering form with fingers, thumb, palm/back, and wrist/cuff appropriate to the declared generic PPE scope.
- Must-not-have components: No universal chemical-resistance claim, food-service-only visual code, logo, or unsupported material label.
- Mechanically necessary relationships: Finger and thumb geometry must be anatomically coherent and connected to palm/cuff.
- Permitted real-world variation: Disposable, reusable, gauntlet, coated, and task-specific forms vary. One asset cannot represent universal chemical compatibility.
- Distinguishing features: PPE hand covering versus unrelated eye/hearing PPE; not distinguished by color.
- Articulation/moving parts: Soft hand pose; no mechanical articulation.
- Soft/deformable components: Entire glove is deformable.
- Real-world scale: Low for identification; cuff length matters if a specific subtype is taught.
- Minimum useful views: Palm and back views; 3/4 optional.
- Ambiguity risk: A generic picture can imply a material/protection claim that the sources do not support.
- Evidence: C-TAXONOMY; P-OSHA-GLOVES; observed 2026-08-20. Editorial display choices are identified as such above.

#### 4. `tool.adjustable-wrench` - Adjustable wrench

- Must-have visible components: Handle, fixed jaw, sliding movable jaw, adjustment worm, and smooth parallel gripping faces.
- Must-not-have components: No serrated pipe-gripping teeth, hook jaw, heel jaw, or angled pipe-wrench jaw profile.
- Mechanically necessary relationships: The movable jaw slides in a guide; the worm engages the jaw rack; gripping faces remain parallel across the adjustment range.
- Permitted real-world variation: Head angle, handle covering, jaw capacity, and length vary. Brand-specific extra-wide jaws must not become the generic silhouette.
- Distinguishing features: Smooth parallel jaws and worm versus serrated biased pipe-wrench jaws and hook/heel arrangement.
- Articulation/moving parts: Movable jaw translation and worm rotation.
- Soft/deformable components: Optional grip coating only.
- Real-world scale: Medium; jaw capacity and head/handle proportion affect recognizability.
- Minimum useful views: Profile, 3/4, and close feature view of jaws/worm.
- Ambiguity risk: Community assets mislabeled adjustable wrench may contain teeth or wood handles; those fail invariants.
- Evidence: C-TAXONOMY; S-ISO6787; S-ASME107100; P-BAHCO-8072; observed 2026-08-20. Editorial display choices are identified as such above.

#### 5. `tool.pipe-wrench` - Pipe wrench

- Must-have visible components: Handle/body, fixed heel jaw, moving hook jaw/shank, adjusting nut, and visible serrated gripping faces.
- Must-not-have components: No smooth parallel adjustable-wrench jaw pair or absent adjustment mechanism.
- Mechanically necessary relationships: Hook jaw travels through its guide; nut controls position; hook and heel jaw teeth face the pipe opening and are biased/nonparallel enough to grip round work.
- Permitted real-world variation: Straight, offset, end, compound-leverage, aluminum, and cast-iron forms vary. First asset should declare straight pipe wrench.
- Distinguishing features: Serrated angled hook/heel jaws and adjusting nut versus smooth parallel jaws and worm.
- Articulation/moving parts: Hook-jaw translation, nut rotation, limited ratcheting compliance in real products.
- Soft/deformable components: None.
- Real-world scale: Medium; nominal length/capacity vary widely.
- Minimum useful views: Profile, 3/4, and jaw/adjuster close-up.
- Ambiguity risk: The canceled federal spec is historical; manufacturer geometry is product-specific; tooth pitch/contour remain editorial without measurement.
- Evidence: C-TAXONOMY; P-RIDGID-PIPE; S-GGG-W651E; observed 2026-08-20. Editorial display choices are identified as such above.

#### 6. `tool.plunger.cup` - Cup plunger

- Must-have visible components: Handle and a simple flexible cup with an open sealing rim.
- Must-not-have components: No extended toilet flange/sleeve beneath the cup.
- Mechanically necessary relationships: Handle attaches at cup crown; cup opens away from the handle and forms an uninterrupted sealing rim.
- Permitted real-world variation: Cup diameter, dome contour, material, and handle length vary.
- Distinguishing features: Absence of extended flange beneath cup.
- Articulation/moving parts: No rigid joint; rubber deforms during use.
- Soft/deformable components: Cup is deformable.
- Real-world scale: Low to medium; profile distinction must remain visible at quiz size.
- Minimum useful views: Profile, 3/4, and underside feature view.
- Ambiguity risk: A single front view can hide an internal or folded flange; underside corroboration is required.
- Evidence: C-TAXONOMY; P-HDX-CUP; observed 2026-08-20. Editorial display choices are identified as such above.

#### 7. `tool.plunger.flange` - Flange plunger

- Must-have visible components: Handle, flexible cup, and an extended flange/sleeve visibly projecting beneath the cup.
- Must-not-have components: No simple cup-only underside.
- Mechanically necessary relationships: Flange is continuous with or securely attached to the cup and extends into the drain opening below the cup rim.
- Permitted real-world variation: Flange length, foldability, cup contour, and handle vary.
- Distinguishing features: Extended flange beneath cup.
- Articulation/moving parts: No rigid joint; rubber deforms/folds.
- Soft/deformable components: Cup and flange are deformable.
- Real-world scale: Low to medium; flange must not be lost at small size.
- Minimum useful views: Profile, low 3/4, and underside feature view.
- Ambiguity risk: Retail photos often hide the flange; exact contour is weakly standardized.
- Evidence: C-TAXONOMY; P-LIBMAN-PLUNGER; observed 2026-08-20. Editorial display choices are identified as such above.

#### 8. `access.stepladder` - Stepladder

- Must-have visible components: Front climbing section, rear support section, top hinge/cap, steps, and spreaders/bracing that hold a self-supporting A-frame.
- Must-not-have components: No overlapping telescoping fly/base rails as the defining form.
- Mechanically necessary relationships: Front and rear sections hinge at top; spreaders lock/open the stance; feet contact ground independently.
- Permitted real-world variation: Wood, metal, fiberglass, platform, twin-front, and size variations; first asset should declare ordinary single-front stepladder.
- Distinguishing features: Self-supporting A-frame and spreaders versus overlapping extension sections.
- Articulation/moving parts: Top hinge and spreaders.
- Soft/deformable components: Foot pads may be elastomeric.
- Real-world scale: High for safe recognition, but scored art remains expressly not to scale.
- Minimum useful views: Side profile showing A-frame, 3/4, and spreader/hinge feature view.
- Ambiguity risk: Closed stepladder can resemble a straight ladder; scored view must show open self-supporting geometry.
- Evidence: C-TAXONOMY; S-ANSI-A14; S-OSHA-STEP; observed 2026-08-20. Editorial display choices are identified as such above.

#### 9. `access.extension-ladder` - Extension ladder

- Must-have visible components: Two or more overlapping ladder sections with rails/rungs and locks/guides appropriate to a non-self-supporting extension ladder.
- Must-not-have components: No rear support section or A-frame spreaders implying self-support.
- Mechanically necessary relationships: Fly section translates relative to base section while retained in guides/locks; rails remain parallel.
- Permitted real-world variation: Rope/pulley systems, materials, rung locks, and section count vary.
- Distinguishing features: Overlapping telescoping rails/sections and lack of A-frame rear support.
- Articulation/moving parts: Linear extension; rope/pulley and rung locks may move.
- Soft/deformable components: Rope and foot pads.
- Real-world scale: High for proportions and overlap.
- Minimum useful views: Profile, 3/4, and overlap/rung-lock feature view.
- Ambiguity risk: A single unextended section can look like a straight ladder; overlap must be visible.
- Evidence: C-TAXONOMY; S-ANSI-A14; S-OSHA-EXT; observed 2026-08-20. Editorial display choices are identified as such above.

#### 10. `tool.hammer.claw` - Claw hammer

- Must-have visible components: Handle, head with flat striking face, and a bifurcated claw opposite the face.
- Must-not-have components: No spherical/hemispherical peen replacing the claw.
- Mechanically necessary relationships: Face and claw are opposite ends of one head securely mounted to handle.
- Permitted real-world variation: Straight/curved/rip claw, face texture, handle material, and head mass vary.
- Distinguishing features: Split claw versus rounded peen.
- Articulation/moving parts: None.
- Soft/deformable components: Optional grip.
- Real-world scale: Low; head proportions matter.
- Minimum useful views: Side/profile and 3/4; claw end feature view.
- Ambiguity risk: Claw slot can disappear in low-resolution line art.
- Evidence: C-TAXONOMY; S-ASME107400; observed 2026-08-20. Editorial display choices are identified as such above.

#### 11. `tool.hammer.ball-peen` - Ball-peen hammer

- Must-have visible components: Handle, flat striking face, and rounded ball peen opposite the face.
- Must-not-have components: No bifurcated claw.
- Mechanically necessary relationships: Face and ball peen are opposite ends of one head mounted to handle.
- Permitted real-world variation: Peen radius, face diameter, handle material, and mass vary.
- Distinguishing features: Rounded ball peen versus split claw.
- Articulation/moving parts: None.
- Soft/deformable components: Optional grip.
- Real-world scale: Low; head detail matters.
- Minimum useful views: Side/profile and 3/4; peen feature view.
- Ambiguity risk: A shallow perspective can make the peen appear flat.
- Evidence: C-TAXONOMY; S-ASME107400; observed 2026-08-20. Editorial display choices are identified as such above.

#### 12. `tool.pliers.slip-joint` - Slip-joint pliers

- Must-have visible components: Two handles/jaws, pivot, and a simple slot or two-position joint that changes jaw opening.
- Must-not-have components: No long arc of multiple tongue-and-groove positions as the defining joint.
- Mechanically necessary relationships: Both halves rotate about the selected pivot position; jaws oppose each other.
- Permitted real-world variation: Jaw serrations, cutter near pivot, handle grips, and lengths vary.
- Distinguishing features: Simple two-position slip joint versus multiple groove positions.
- Articulation/moving parts: Pivot rotation plus pivot relocation between limited positions.
- Soft/deformable components: Grip covers optional.
- Real-world scale: Low to medium; pivot geometry must be legible.
- Minimum useful views: Profile open pose, 3/4, and pivot feature view.
- Ambiguity risk: Closed poses hide the slot; small line art can merge pivot and groove.
- Evidence: C-TAXONOMY; S-ASME107500; S-ISO5743; observed 2026-08-20. Editorial display choices are identified as such above.

#### 13. `tool.pliers.tongue-groove` - Tongue-and-groove pliers

- Must-have visible components: Two handles/jaws, pivot, and multiple selectable grooves/positions producing a broad adjustable opening.
- Must-not-have components: No simple single/two-position slip slot as the only adjustment.
- Mechanically necessary relationships: One member tongue seats in one of several grooves; jaws remain opposed through selected positions.
- Permitted real-world variation: Groove count, jaw angle, handle length, and grip covers vary.
- Distinguishing features: Multiple grooves and larger offset jaw range versus simple slip joint.
- Articulation/moving parts: Pivot rotation and multi-position pivot relocation.
- Soft/deformable components: Grip covers optional.
- Real-world scale: Medium; groove train must be visible.
- Minimum useful views: Profile open pose, 3/4, and groove/pivot feature view.
- Ambiguity risk: Brand-specific tongue shape and groove count must not become normative.
- Evidence: C-TAXONOMY; S-ASME107500; S-ISO5743; observed 2026-08-20. Editorial display choices are identified as such above.

#### 14. `tool.pliers.needle-nose` - Needle-nose pliers

- Must-have visible components: Two handles, pivot, and long narrow tapered jaws intended for confined work.
- Must-not-have components: No short diagonal cutting head as the primary working form.
- Mechanically necessary relationships: Tapered jaws oppose and close toward the tip about the pivot.
- Permitted real-world variation: Straight/bent nose, serration, cutter near pivot, spring, and grips vary.
- Distinguishing features: Long tapered gripping jaws versus compact diagonal cutters.
- Articulation/moving parts: Single pivot; optional return spring.
- Soft/deformable components: Grip covers optional.
- Real-world scale: Low to medium; jaw length/taper must survive reduction.
- Minimum useful views: Profile open pose, 3/4, and jaw-tip feature view.
- Ambiguity risk: Optional cutters can confuse the pair; primary silhouette must remain long-nose.
- Evidence: C-TAXONOMY; S-ASME107500; S-ISO5743; observed 2026-08-20. Editorial display choices are identified as such above.

#### 15. `tool.pliers.diagonal-cutting` - Diagonal cutting pliers

- Must-have visible components: Two handles, pivot, and short opposed beveled cutting edges angled across the head.
- Must-not-have components: No long needle-like gripping jaws.
- Mechanically necessary relationships: Cutting edges meet along a coherent cutting line when handles close.
- Permitted real-world variation: Head angle, bevel type, spring, grips, and size vary.
- Distinguishing features: Compact beveled cutting head versus long tapered jaws.
- Articulation/moving parts: Single pivot; optional return spring.
- Soft/deformable components: Grip covers optional.
- Real-world scale: Low to medium; cutting edge must be visible.
- Minimum useful views: Profile open pose, 3/4, and cutting-edge feature view.
- Ambiguity risk: Smooth edge rendering can erase bevels; do not infer cutting ability from label alone.
- Evidence: C-TAXONOMY; S-ASME107500; S-ISO5749; observed 2026-08-20. Editorial display choices are identified as such above.

#### 16. `tool.push-broom` - Push broom

- Must-have visible components: Long handle attached to a broad transverse head with a wide bristle field directed toward the floor.
- Must-not-have components: No narrow compact scrub block or cup-shaped head.
- Mechanically necessary relationships: Handle socket joins near head center; bristles are rooted across the broad head.
- Permitted real-world variation: Head width, bristle stiffness, brace, socket angle, and handle vary.
- Distinguishing features: Broad sweeping head versus narrower stiff deck-brush block.
- Articulation/moving parts: Usually fixed; threaded removable handle is not an in-use joint.
- Soft/deformable components: Bristles deform.
- Real-world scale: Medium; relative head width is instructional.
- Minimum useful views: Profile/side, 3/4, and underside bristle view.
- Ambiguity risk: A close crop can make broad and narrow brush heads appear equal.
- Evidence: C-TAXONOMY; P-LIBMAN-PUSH; observed 2026-08-20. Editorial display choices are identified as such above.

#### 17. `tool.deck-brush` - Deck brush

- Must-have visible components: Long handle attached to a compact brush block with short, relatively stiff scrubbing bristles.
- Must-not-have components: No very broad push-broom sweep head as the canonical form.
- Mechanically necessary relationships: Handle/socket is mechanically joined to block; bristles project to work surface.
- Permitted real-world variation: Block width, bristle material, socket angle, and handle vary.
- Distinguishing features: Compact stiff scrubbing head versus broad sweeping head.
- Articulation/moving parts: Usually fixed.
- Soft/deformable components: Bristles deform.
- Real-world scale: Medium; pair-normalized framing is required.
- Minimum useful views: Profile/side, 3/4, and underside bristle view.
- Ambiguity risk: Without scale or comparable framing, a deck brush can look like a small push broom.
- Evidence: C-TAXONOMY; P-LIBMAN-SCRUB; P-LIBMAN-PUSH; observed 2026-08-20. Editorial display choices are identified as such above.

#### 18. `equipment.floor-machine.low-speed` - Low-speed rotary floor machine

- Must-have visible components: Declared product-family geometry: floor-contact rotary brush/pad deck, motor/body, operator handle/control, wheels and cord/battery features only where sourced.
- Must-not-have components: No invented universal low-speed silhouette or unsupported RPM cutoff.
- Mechanically necessary relationships: Pad/brush axis is normal to floor; handle and wheels support/operator-control the deck.
- Permitted real-world variation: Single/dual speed, deck diameter, handle, motor housing, wheels, cord/battery, and accessories vary widely.
- Distinguishing features: No single reliable silhouette distinction established; use source-specific model plus broad task context.
- Articulation/moving parts: Handle pivot/fold; rotating pad/brush; wheels.
- Soft/deformable components: Pad/brush and cord.
- Real-world scale: High for deck/handle relation, but model-specific.
- Minimum useful views: Profile, 3/4, and underside/deck feature only for atlas; scored use should be blocked until fairness review.
- Ambiguity risk: Repository explicitly forbids fictitious universal silhouette; product-specific trade dress is high.
- Evidence: C-TAXONOMY; C-SCOPE; P-TENNANT-FM20; P-NILFISK-FM400D; observed 2026-08-20. Editorial display choices are identified as such above.

#### 19. `equipment.burnisher.high-speed` - High-speed burnisher

- Must-have visible components: Declared product-family geometry: floor-contact burnishing pad/deck, motor/body, operator handle/control, wheels and power system only where sourced.
- Must-not-have components: No invented universal high-speed silhouette or universal RPM boundary.
- Mechanically necessary relationships: Pad axis and deck contact floor; handle/wheels control and support machine.
- Permitted real-world variation: Corded/battery/propane, walk-behind/ride-on, deck and head forms vary widely.
- Distinguishing features: No single reliable generic silhouette established; use reviewed real equipment characteristics and task context.
- Articulation/moving parts: Handle/head pivot, pad rotation, wheels.
- Soft/deformable components: Pad and cord.
- Real-world scale: High and model-specific.
- Minimum useful views: Profile, 3/4, and deck/head feature for atlas; scored art blocked until fair distinguishing invariant exists.
- Ambiguity risk: Burnishers can overlap floor-machine silhouettes; manufacturer styling can dominate.
- Evidence: C-TAXONOMY; C-SCOPE; P-TENNANT-B5; P-NILFISK-FM400D; observed 2026-08-20. Editorial display choices are identified as such above.

#### 20. `tool.hand-plane` - Hand plane

- Must-have visible components: Rigid sole/body, mouth, cutting iron/blade projecting through mouth, and grips/knob appropriate to declared bench-plane subtype.
- Must-not-have components: No saw teeth, motor, sanding belt, or absent cutting iron.
- Mechanically necessary relationships: Blade is clamped in body at a controlled angle and reaches the sole through mouth; grips are attached to body.
- Permitted real-world variation: Block, bench, jack, smoothing, wooden, metal, knob/tote configurations vary. First asset must declare subtype.
- Distinguishing features: Sole and mouth with cutting iron versus saw/sander forms.
- Articulation/moving parts: Blade depth/lateral adjustment mechanisms; no animation required unless taught.
- Soft/deformable components: Optional grip insert only.
- Real-world scale: Medium; mouth/blade details must survive reduction.
- Minimum useful views: Side/profile, 3/4 from above, and sole/mouth feature view.
- Ambiguity risk: Hand plane is a family, not one universal silhouette; official role is only distractor-level evidence.
- Evidence: C-TAXONOMY; P-STANLEY-PLANE; observed 2026-08-20. Editorial display choices are identified as such above.

## 3. Standards and parametric-data coverage matrix

| Source/system | Edition/version | Organization | Data type | Formats | Normative dimensions? | Complete geometry? | Measured taxonomy coverage | Access/versioning | Rights | Verdict | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ISO 6787 | 2018; confirmed current in 2025 review | ISO | Dimensional/performance standard | Document/PDF/OBP | Yes: specified dimensions, jaw clearances, tests | No | Adjustable wrench: 1/65 | Paid full text; periodic ISO review | Copyrighted document; no asset rights | Useful evidence, not model source | S-ISO6787 |
| ASME B107.100 | 2023 | ASME | Flat-wrench dimensions/performance/safety | PDF/subscription | Yes for covered wrench types | No | Adjustable and fixed wrench concepts: 2/65 | Paid/subscription; revisions by ASME | Copyrighted document; no asset rights | Useful evidence, not model source | S-ASME107100 |
| ASME B107.400 | 2018, reaffirmed 2023 | ASME | Striking-tool performance/safety | PDF/subscription | Principal dimensions/tests for covered tools | No | Claw and ball-peen hammers: 2/65 confirmed | Paid/subscription | Copyrighted document; no asset rights | Useful evidence; handle/head contours remain incomplete | S-ASME107400 |
| ASME B107.500 | 2020 | ASME | Pliers/shears performance/safety/dimensional data | PDF/subscription | Some dimensions and functional data | No | Four priority plier concepts directly within scope: 4/65 | Paid/subscription | Copyrighted document; no asset rights | Useful family evidence; not stock-size or complete CAD | S-ASME107500 |
| ISO 5743 | 2021 | ISO | General technical requirements for pliers/nippers | Document/PDF/OBP | Requirements/tests; not complete shape | No | Pliers family; 4/65 priority concepts | Paid full text | Copyrighted document | Supporting requirements only | S-ISO5743 |
| ISO 5749 | 2004; current confirmed in 2021 | ISO | Diagonal cutting nipper dimensions/tests | Document/PDF/OBP | Principal dimensions/tests | No | Diagonal cutting pliers: 1/65 | Paid full text | Copyrighted document | Strong invariant source; complete profile still undefined | S-ISO5749 |
| ANSI-ASC A14 package | A14.1/A14.2/A14.5 package observed current editions | ANSI / ALI | Portable ladder dimensional, performance, use requirements | PDF/subscription | Normative dimensions/performance for covered ladder types; not every construction detail | No | Stepladder and extension ladder: 2/65 | Paid package/subscription; editioned | Copyrighted documents | Strong functional envelope, requires authored generic geometry | S-ANSI-A14; S-OSHA-STEP; S-OSHA-EXT |
| GGG-W-651E | Cancelled; no superseding document listed in result | US GSA / DLA | Historical federal pipe-wrench specification | PDF via ASSIST when available | Historical dimensions/performance may be normative to procurement | No | Pipe wrench: 1/65 | Public search; cancelled | US government document; status/embedded rights review | Reference only; not current generic authority | S-GGG-W651E |
| ETIM Product Classification | 10.0, 2024-12-10 | ETIM International | Naming/classification/features | IXF 3.1 XML, CSV, Excel | Attributes can include dimensions, but values are product records, not a generic normative shape | No | Exact 65-term class count not reproducibly located; at least general cleaning/tool classes exist | English release downloadable; change requests; biennial/dynamic model | ETIM license controls database use; asset rights not granted | Vocabulary/attribute assistance only | D-ETIM10; D-ETIM-LICENSE |
| ETIM MC | Guidelines 2.0, 2025-12-09; current model reported 360 classes | ETIM International | Geometric modeling classes and parameter conventions | Guidelines, modeling database/API | Parameters may be normative within a modeling class | Parametric envelope, not necessarily complete manufacturable detail | Exact taxonomy overlap not located | Guidelines public; database/governance may require membership/API terms | No blanket redistribution right located | Promising for building products, not proven for this hand-tool taxonomy | D-ETIMMC2; D-ETIM-LICENSE |
| ECLASS Advanced | Release 16.0, 2025-11-28 | ECLASS e.V. | Classification, properties, blocks, aspects for CAx | XML/CSV/OWL/JSON variants by licensed package | Structured product properties; not complete generic geometry | No | Exact 65-term licensed-release coverage not measured | Annual release; paid license/order | License agreement controls database and redistribution | Useful terminology/data mapping; not geometry source | D-ECLASS16; D-ECLASS-ADV; D-ECLASS-LICENSE |
| STEP AP242 | ISO 10303-242:2025 edition 4 | ISO | Neutral CAD/product-data interchange | STEP Part 21, XML/implementation variants | Carries units, B-rep, CSG, parametric/constrained geometry, tessellation and PMI | Yes, if geometry already exists | Delivery capability 65/65; source coverage 0/65 | Paid standard; implementations versioned | Standard copyrighted; generated files have separate rights | Recommended neutral master/interchange, not authoring evidence | F-STEP242 |
| IFC | ISO 16739-1:2024 edition 2 / IFC 4.3 lineage | ISO / buildingSMART | Building/infrastructure BIM schema | STEP physical file, XML, JSON implementations | Can carry product placement/shape representations | Can carry geometry, but not tool semantics | 0/65 direct taxonomy classes located | Editioned standard/schema | Schema terms apply; model rights separate | Not suitable as hand-tool master; only relevant for installed building products | F-IFC |
| glTF/GLB | glTF 2.0 | Khronos | Web/runtime delivery | JSON + buffers or binary GLB | No normative tool dimensions | Complete tessellated delivery geometry only | Delivery capability 65/65; source coverage 0/65 | Open versioned spec | Asset license remains separate | Recommended derived web format only | F-GLTF |
| Manufacturer drawings/CAD portals | Per current product/revision | Manufacturer | Product-specific dimensions, drawings, sometimes CAD | PDF/DXF/DWG/STEP/IGES/native CAD varies | Product dimensions can be authoritative for that SKU | Sometimes complete product geometry | Potentially broad, but generic coverage 0/65 by itself | Usually free/account; mutable product lifecycle | Terms usually reference-only unless express redistribution license | Essential corroboration; never silently genericize trade dress | P-BAHCO-8072; P-RIDGID-PIPE; P-LIBMAN-PLUNGER |
| TraceParts / 3D ContentCentral / PARTcommunity | Current services observed 2026-08-20 | Commercial portals | Aggregated supplier CAD | Many CAD formats | Product-specific; portal disclaims accuracy | Often complete SKU geometry | Hit counts not accepted as coverage; 0 accepted assets | Free/account/service terms | Terms restrict public/commercial redistribution and/or modification | Reference discovery only unless separate controlling asset license exists | L-TRACEPARTS; L-3DCC; L-PARTCOMMUNITY |

For standards that provide principal dimensions only, a complete model still needs at least: body/handle contours; cross-sections and wall thickness; fillet/chamfer radii; fasteners; clearances; material deformation; exact tooth/rack/thread profiles; articulation axes/stops; and a documented decision about which real-world subtype is canonical. Those missing fields must be measured or left explicitly editorial/unknown. This is an Inferred gap analysis from the cited scopes and the proof models.

## 4. Open 3D dataset coverage and rights matrix

The audit query dictionary was the 65 canonical terms plus common synonyms such as Stillson wrench, adjustable spanner, channel-lock-style pliers (used only as a search synonym, not a canonical brand term), sink plunger, toilet plunger, floor buffer, rotary scrubber, burnisher, strip washer, and hand dolly. Exact full-taxonomy hit counts were recorded only where an official interface/metadata result could be reproduced. Where this was not possible, the matrix says `Not located` rather than inventing a count.

| Collection | Scale | Search performed | Exact hits | Provenance | Geometry QA | Rights | Result | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Google Scanned Objects | 1000+ real-object scans | 65 terms/synonyms against official project/repository metadata | Not located; no reproducible official full-text count | Scanned real objects; simulation assets are processed derivatives | Scale/units and per-asset completeness need object inspection | Repository release is not a blanket license for all underlying CAD/textures | 0 accepted; E/reference or F | DS-GSO |
| Amazon Berkeley Objects | 7,953 3D models among 147,702 products | 65 terms/synonyms against official explorer/metadata descriptions | Not located in a reproducible exported query | Primarily product CAD/3D associated with listings | Product scale can exist but SKU/trade dress/logo dependence is high | Official page/AWS registry license conflict (CC BY versus CC BY-NC observed) | 0 accepted; production blocked pending license resolution | DS-ABO; DS-ABO-AWS |
| Objaverse | 800K+ objects | Canonical/synonym searches through source metadata and representative source pages | Not located as a stable official total | Mixed artist-authored, scans, CAD, photogrammetry, unknown | Highly variable; per-object disconnected parts, scale, logos, topology expected | Per-object source license; collection name does not control all assets | 0 accepted; E/reference discovery only | DS-OBJAVERSE |
| Objaverse-XL | 10M+ objects from multiple sources | Canonical/synonym metadata search conceptually supported; stable exact totals not reproduced | Not located | Mixed and source-dependent, including generated annotations | Extremely variable; provenance and source revalidation mandatory | Per-source/per-object licenses | 0 accepted; bulk ingestion prohibited | DS-OBJAVERSE-XL |
| Smithsonian Open Access 3D | Institutional scans/models | Priority taxonomy terms and common synonyms in 3D/Open Access discovery | No relevant priority model count located | Institutional scans/reconstructions with catalog provenance | Usually valuable scale/provenance where present; model-specific review still needed | Only Open Access-marked assets are CC0; not all Smithsonian items are open | 0 accepted; promising D/B only if exact asset found | DS-SMITHSONIAN |
| Poly Haven | Curated CC0 assets | Priority terms and synonyms | Four relevant asset pages located: adjustable wrench, pipe wrench, plunger, plastic broom; not an exhaustive API total | Artist/scan provenance is asset-specific | High technical quality, but mechanical genericness must be checked | CC0 collection assets | 0 accepted; adjustable wrench rejected; three remain unreviewed candidates | DS-POLYHAVEN; DS-POLY-ADJ; DS-POLY-PIPE; DS-POLY-PLUNGER; DS-POLY-BROOM |
| Sketchfab downloadable models | Marketplace-scale mixed library | Priority terms via public Data API/search and representative asset review | Exact stable total not reproduced; API/service results are mutable | Mixed artist-authored, scans, CAD, AI/unknown | Scale, topology, floating parts, texture dependence and trade dress vary | Per-asset CC or platform license; `downloadable` is not reuse permission | 0 accepted; representative pipe-wrench asset used a non-CC platform license | DS-SKETCHFAB-API |
| Wikimedia Commons 3D | Per-file community repository | Canonical terms/synonyms plus 3D-file constraint | Exact 3D-only counts not located; ordinary search mixes 2D/3D | Mixed authored models/scans | Per-file technical quality and scale vary | Exact file page license controls; attribution/share-alike may apply | 0 accepted in this pass; strong D/B discovery channel | DS-WIKIMEDIA3D |
| ShapeNet | Research taxonomy/model corpus | Tool terms where classes exist | Not material after license gate | CAD/artist models assembled for research | Scale and category quality vary | Academic noncommercial research terms | Unusable for production: F | DS-SHAPENET |

Representative rejection: the Poly Haven asset named `Adjustable Wrench` describes sharp teeth and a wood handle. Those features violate the canonical adjustable-wrench invariant of smooth parallel jaws and demonstrate why a filename/category is not geometry evidence [Confirmed; DS-POLY-ADJ and C-TAXONOMY; observed 2026-08-20].

## 5. CAD/model source and licensing analysis

| Source type | Geometry authority | Genericness | Rights default | Production class |
| --- | --- | --- | --- | --- |
| Normative/open parametric specification | Potentially high if complete | Can define generic class | Only if exact specification/data license permits generated derivatives | A; none located |
| Reusable CAD/scan with suitable license | Asset geometry only; must pass review | Often product/instance-specific | Exact asset license controls; source URL and author required | B after review |
| Project-authored model | Project geometry controls; evidence fields distinguish sourced vs editorial | Can intentionally model generic subtype | Original geometry rights can be cleared; reference materials not redistributed | C |
| Rights-cleared 2D photo/drawing | Visible geometry only; hidden geometry remains unknown | Instance-specific unless carefully selected | Exact per-file license/photographer release controls | D |
| Manufacturer/portal/unclear asset | Useful facts or visual reference | Usually SKU/trade dress-specific | Reference-only absent express commercial derivative/redistribution permission | E |
| No adequate source | None | Unknown | No publication right or accuracy basis | F |

TraceParts, 3D ContentCentral, and PARTcommunity are not suitable production-source libraries under the observed general terms. Their downloads can assist reference and compatibility work, but the terms restrict public/commercial redistribution and/or modification and disclaim accuracy; a separate manufacturer/asset license would have to control [Confirmed; L-TRACEPARTS, L-3DCC, L-PARTCOMMUNITY; observed 2026-08-20].

Manufacturer drawings and CAD are authoritative for the exact SKU and revision only. They should contribute measured facts, component relationships, and comparison ranges, not be republished or silently normalized into a generic tool unless the manufacturer expressly licenses modification and redistribution. Brand marks, logos, molded text, signature contours, and unusual product features must be removed only through a genuinely original reconstruction, not by editing copyrighted CAD [Inferred; product sources and rights constraints].

## 6. Recommended deterministic authoring pipeline

### Tool comparison

| Tool | Exact parameter control | Curved/articulated tools | STEP | GLB | SVG/line art | Headless Linux | Reviewability | License | Verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CadQuery 2.8.x | High; Python values/types and OCCT B-rep | Strong; assemblies and scripted kinematic poses | Strong | Derived through tessellation/export | OCCT projection/hidden-line workflows | Yes | High for disciplined modules/JSON parameters | Apache-2.0 | Primary |
| build123d 0.10.x | High; Python/OCCT | Strong and ergonomic for complex construction | Strong | Derived | SVG/DXF plus OCCT workflows | Yes | High | Apache-2.0 | Strong alternative; choose one project-wide |
| FreeCAD Python 1.1.x | High but document-object state can add complexity | Strong; broad workbenches | Strong | Possible/derived | TechDraw/hidden-line paths | Yes via command line, but heavier | Medium; document state and GUI heritage add review noise | LGPL-2.0-or-later | Secondary inspection/conversion tool |
| OpenSCAD 2021.01 | High for constructive solids | Weak to medium for organic, sculpted, and articulated tools | Not native robust B-rep STEP | Derived via mesh conversion | Projection/DXF but limited hidden-line quality | Yes | Very high for simple solids | GPL-2.0-or-later | Use only for simple fixtures/prototypes |
| Direct OCCT | Maximum | Maximum, but substantial engineering cost | Maximum | Derived | Maximum HLR control | Yes | Low unless wrapped in project abstractions | LGPL-2.1 with exception | Kernel under CadQuery; avoid direct use initially |
| Blender Python 4.5 LTS | Exact transforms but polygonal authoring, modifier/version sensitivity | Excellent for deformable/organic and presentation | Weak as authoritative STEP/B-rep source | Strong | Freestyle/line art/raster NPR | Yes | Medium; visual modifier stacks harder to diff | GPL-2.0-or-later | Supporting renderer/mesh optimizer only |

Software versions and release status were observed on 2026-08-20 [SW-CADQUERY, SW-BUILD123D, SW-FREECAD, SW-OCCT, SW-BLENDER, SW-OPENSCAD]. The controlled production environment should pin an OCI image by immutable digest, not a floating tag.

### Canonical geometry conventions

- Authoring units: millimetres.
- Authoring coordinates: right-handed, +Z up. +X follows the principal tool/handle axis where one exists; otherwise each class records a functional forward axis.
- Origin: a stable functional datum, not a bounding-box center. Examples: jaw-contact datum for wrenches, cup-axis/rim plane for plungers, floor-contact center for machines.
- Neutral master: normalized STEP AP242. Source code and evidence JSON remain controlling.
- Web delivery: GLB 2.0 in metres, right-handed +Y up, transformed from CAD as `(x,y,z)_mm -> (x,z,-y)_m`. Node names and extras are neutral.
- Names: private taxonomy IDs such as `tool.adjustable-wrench`; opaque served asset IDs such as `a-01h...`; neutral GLB nodes `part-001`; no answer terms in scored URLs or filenames.
- Canonical cameras: orthographic 3/4 `(1,-1,0.7)`, family profile, and one feature view selected from the invariant sheet. Camera vectors are versioned parameters.
- Master build has no network access. All source files and licenses are vendored or captured before approval.

### Geometry validation gates

1. B-rep validity and positive volumes.
2. Expected named component count and permitted contact/intersection matrix.
3. Watertight derived component meshes; no non-manifold or floating parts unless explicitly declared soft/loose.
4. Bounding dimensions against dimension records and tolerances.
5. Functional constraints: parallel/smooth adjustable-wrench faces, serrated pipe-wrench faces, flange-present/absent, hinge/guide axes, tooth/cutter/keypoint counts where sourced.
6. Brand/text/logo scan and trade-dress review.
7. Static silhouette, crease-edge, and keypoint regression against the last approved version.
8. Human mechanical review by a reviewer independent of the model author. Automation cannot decide whether a generic form fairly represents a tool class.

### Reproducibility

Operational deterministic definition: identical source files/hashes + identical container digest/toolchain + identical parameters + identical render configuration must produce identical output hashes. The POC met exact SHA-256 identity for 79 files across two clean builds on the same controlled Linux runtime [Confirmed; POC generated 2026-08-20].

Cross-platform bit identity is not promised because OCCT tessellation/entity ordering, font/render libraries, PNG encoders, floating-point behavior, and system libraries can vary. Outside the controlled image, the acceptance proposal is: normalized SVG path/attribute equality where possible; 2048 px raster difference no more than 0.1 percent of pixels with maximum channel delta greater than 2; silhouette IoU at least 0.995; and functional keypoints within 1 pixel or 0.1 percent of frame, whichever is larger. These thresholds are editorial starting points and require calibration on the first approved tranche.

## 7. Recommended static-render pipeline

Primary method: OCCT hidden-line removal from the B-rep, followed by deterministic SVG normalization. Render silhouette and visible crease/boundary edges first; add only scripted functional hatching based on declared material/normal/depth rules. Do not use automatic artistic hatching that can obscure teeth, flanges, joints, or cutter edges.

| Method | Small-feature preservation | Determinism | Verdict |
| --- | --- | --- | --- |
| CAD hidden-line B-rep rendering | Best for exact boundaries, jaws, flange, rails, joints; curve topology retained | High in pinned OCCT environment | Primary |
| Mesh silhouette + crease edges | Good if mesh is sufficiently dense; can lose tiny B-rep features | High with fixed tessellation/edge thresholds | Derived QA/GLB fallback |
| Blender Freestyle/NPR | Flexible but line selection depends on mesh/modifiers/version | Medium to high when pinned | Optional presentation renderer, not controlling |
| Raster edge extraction | Can double edges and erase shallow features | High with fixed algorithm | QA/secondary derivative only |
| Vector tracing of raster | May invent/simplify topology | Deterministic but mechanically risky | Reject as primary |
| Scripted line simplification | Useful after feature tags protect critical edges | High | Allowed only with protected-edge and regression gates |
| Scripted hatching | Safe when tied to material/depth regions and exclusion masks | High | Sparse optional layer |

Recommended style configuration: pure white background; black strokes; no grayscale shading or brands; 0.45-0.65 mm print-equivalent primary line; thinner secondary crease lines; round caps/joins; no decorative crosshatching; SVG at 1600 logical pixels; PNG 2048 x 2048; lossless WebP 1024 or 1536; an additional print SVG/PDF derivative. Canonical pair framing uses the same family viewport and orthographic projection, not independent object auto-fit.

Functional edge policy: jaw serrations, flange outline, ladder rail overlap/spreaders, pivot/slot/groove geometry, blade/mouth, and cutting bevels are protected edges that simplification may not remove. If a distinction is below the target display resolution, the scored pair is blocked rather than enlarged deceptively.

Editorial delivery budgets: ordinary hand tool GLB <= 250,000 triangles and <= 2 MB compressed; powered equipment <= 500,000 triangles and <= 5 MB; scored static WebP <= 120 KB and SVG <= 250 KB when feasible. These are product targets, not facts derived from standards.

## 8. Static versus interactive 3D decision

| Context | Recommendation | Reason |
| --- | --- | --- |
| Scored quiz pages | Fixed static render only | Rotation can reveal a flange, hidden jaw surface, ladder overlap, underside pad, or other feature and therefore changes item difficulty. The prompt/view is part of the item. |
| Atlas/reference pages | Static controlling views plus optional user-invoked GLB | Multiple angles improve learning; static images remain accessible, indexable, printable, cacheable, and mechanically reviewed. |
| Printable packets | SVG/PDF line art, raster fallback | No interactive dependency; predictable black-and-white output. |
| Offline/PWA | Cache static assets by default; download selected GLBs as optional packs | Avoid mandatory large meshes; keep atlas usable without WebGL. |
| Low-bandwidth mobile | SVG or responsive WebP/PNG; never auto-load GLB | Fast, robust, and preserves scored-view control. |

Interactive 3D must not be embedded in scored attempts. Even a rotation-only viewer changes the visible evidence, and model metadata or node names can leak the answer. Atlas GLBs must have neutral delivery metadata, keyboard/touch controls, reduced-motion behavior, static fallback, and no analytics dependency [Inferred; C-TAXONOMY, C-LANDSCAPE].

## 9. Image-generation risk and verdict

**Production verdict: do not add an image-generation style pass.** The requested black-on-white line style is already achievable by hidden-line CAD rendering and scripted vector processing. A generative pass adds model-version, sampler, floating-point, and semantic-drift risks without adding instructional information. `It looks nicer` is not a sufficient benefit [Inferred].

A research-only pass may proceed only if all of the following are true: immutable local model and exact hash; fixed seed/sampler/scheduler/precision; deterministic input render plus retained depth, normal, silhouette, object-ID and edge maps; silhouette IoU >= 0.995; protected-edge recall 100 percent; no component-count/topology change; functional keypoints within the calibrated tolerance; pixel/edge comparison; and side-by-side human mechanical review. Any added, removed, merged, displaced, or re-proportioned part is an automatic rejection. The pre-generation render remains controlling. A hosted mutable service is classified non-deterministic.

## 10. Rights-cleared 2D fallback

| Fallback | Coverage | Rights rule | Mechanical/maintenance result |
| --- | --- | --- | --- |
| Original project photography + measurement | Potentially all obtainable tools | Photographer/property releases and project-owned files; remove marks/trade dress where possible | Best fallback; capture orthogonal/multi-view scale targets and measurement log; supports Class C or D |
| Wikimedia Commons | Variable | Verify exact file page; CC BY/CC BY-SA/PD terms control | Good discovery; angle/scale and attribution burden vary |
| Smithsonian Open Access | Narrow for these tools | Only Open Access-marked CC0 items | High provenance but likely low taxonomy coverage |
| US government public-domain manuals/catalogs | Variable and often historical | 17 USC 105 only for qualifying government work; verify embedded third-party material | Useful dimensions/reference; dated forms may not be generic |
| Public-domain catalogs/manuals | Potentially useful for old rigid tools | Verify publication date, jurisdiction, edition, and scans | Can support Class D/reference; modern forms may differ |
| Institutional technical drawings | Narrow | Publication is not automatically a reuse license | Reference-only unless terms expressly permit derivatives/redistribution |
| Licensed commercial photographs | Broad | License must allow commercial derivative work and redistribution of the derivative | Possible Class D; recurring cost and inconsistent views |
| Openverse | Discovery only | Verify at original source | Never a controlling license record |

A photograph may be published directly only when its exact rights permit commercial redistribution, brands/trade dress are acceptable or absent, the view is fair, and the image is mechanically adequate. It may be transformed only when derivatives are expressly allowed and the deterministic transform does not fabricate hidden geometry. It is reference-only when rights, angle, scale, resolution, or brand dependence fail. Release no asset when only a single ambiguous view exists or hidden geometry controls the distinction.

CC BY is generally compatible with commercial derivatives if attribution and license obligations are met [R-CCBY4]. CC BY-SA is conditional: the adapted asset must be distributed under the same license with attribution; the project should isolate the adapted file/attribution record and obtain legal review of the exact distribution boundary [R-CCBYSA4]. NC, ND, research-only, unclear, or conflicting licenses are rejected.

## 11. Proof-of-concept results

The POC is inspectable under `poc-build-a/` and rebuildable with `build_poc.py`. It contains no third-party mesh, image, texture, logo, or official exam drawing. Newly authored POC code/geometry is dedicated CC0-1.0 in the bundle. External standards and product pages are factual references only.

- Build script SHA-256: `55468f47e0e0f0e5c552dd649fc6647ba6cf191ebaee4513f4feea4a1ace5dab`
- Comparison script SHA-256: `5b9fc527a37b3fc425212c842d30cce203f60f7fe0f14e42ec3159fdfbc963b0`
- Determinism: `True`; files A/B: `79/79`; differences: `0`.
- Toolchain: Python 3.13.5, CadQuery 2.8.0, OCP/OCCT 7.9.3.1, trimesh 4.11.1, NumPy 2.3.5, SciPy 1.17.0, Pillow 12.3.0, CairoSVG 2.8.2, Linux x86_64/glibc 2.41.
- Coordinates: source B-rep in mm, right-handed +Z up; GLB in metres, right-handed +Y up.

### t0004 - Adjustable wrench

- Source class/status: C, prototype, human mechanical review pending.
- Source/license record: ISO 6787:2018 Assembly tools for screws and nuts - Adjustable wrenches (copyrighted standard; reference only); Bahco 8072 adjustable wrench product data (manufacturer page; facts reference only; no manufacturer asset reused). Source file hashes are null because those copyrighted/reference-only web documents were not redistributed.
- Authoritative/corroborated geometry: smooth parallel gripping faces; moving jaw; worm adjustment; selected principal dimensions.
- Editorial/inferred geometry: body contour; fillets; guide form; worm tooth form; display opening.
- Automated checks: {"allPartMeshesWatertight": true, "allPartsBrepValid": true, "deliveryMetadataNeutral": true, "noUnexpectedIntersection": true, "partCountMatches": true, "unitsAreMm": true}.
- Bounding box mm: {"xlen": 255.0, "xmax": 52.0, "xmin": -203.0, "ylen": 73.0, "ymax": 38.0, "ymin": -35.0, "zlen": 17.5, "zmax": 8.75, "zmin": -8.75}.
- Manual QA: `poc-build-a/objects/t0004/qa/manual-checklist.json`; status PENDING_HUMAN_MECHANICAL_REVIEW.
- Key output hashes: STEP `a6fa1ed3d0c7ecd196b5e4757e8c468db160dfd79cddf38816e8e085850e574a`; GLB `9e476cd38d99f10a2f5f319d0c794df29c81cdf4aa779f389bb5b55baf9201ed`; 3/4 SVG `8e41eb0248bcba779cf95ceb9c97e791eae36f99cceede7318f18d37b5030c8e`; profile SVG `1e46288f4b21954f784be9c2eda5c65ab4a048329fdcd57a17d965d8f0159aac`; feature SVG `3e21b77c58e7f433039662e04c5ed9aaa622fcf2f68646d3e51f6f053d932afb`. Full hashes are in `poc-summary.json` and per-object validation.
- Pair result: the deterministic render exposes smooth parallel jaws/worm versus serrated hook/heel jaws/adjuster. The bodies and exact contours remain editorial; therefore this is a pipeline success but not a production geometry approval.

### t0005 - Pipe wrench

- Source class/status: C, prototype, human mechanical review pending.
- Source/license record: Heavy-Duty Straight Pipe Wrenches (manufacturer page; facts reference only; no manufacturer asset reused); Federal Specification GGG-W-651E, Wrenches, Pipe (government specification; document status/rights separately reviewed). Source file hashes are null because those copyrighted/reference-only web documents were not redistributed.
- Authoritative/corroborated geometry: hook jaw; fixed heel jaw; serrated gripping surfaces; adjusting nut; selected nominal size/capacity.
- Editorial/inferred geometry: body contour; jaw tooth count/pitch; guide form; nut contour; display opening.
- Automated checks: {"allPartMeshesWatertight": true, "allPartsBrepValid": true, "deliveryMetadataNeutral": true, "noUnexpectedIntersection": true, "partCountMatches": true, "unitsAreMm": true}.
- Bounding box mm: {"xlen": 250.0, "xmax": 50.0, "xmin": -200.0, "ylen": 84.0, "ymax": 66.0, "ymin": -18.0, "zlen": 28.0, "zmax": 14.0, "zmin": -14.0}.
- Manual QA: `poc-build-a/objects/t0005/qa/manual-checklist.json`; status PENDING_HUMAN_MECHANICAL_REVIEW.
- Key output hashes: STEP `f47d4415be05899a10fa8f55be873a50b6955bd3ccd26f5c3e580e502570395a`; GLB `e1d8ad9b9cd68282d3c4ae83ec168c18523c107860a56bcb01adcce5a4c871a8`; 3/4 SVG `8aa0642f913f34b7e37642ed92fad9c367ce9c9e66c1510d899eb10b964d352e`; profile SVG `151088f06d5623305b31d2a6ee713fac622d3f301a37c5a4938a04d7bff3a7b2`; feature SVG `80481016c6007ce2f68a8145ccf7bea79dad540c234a7a4350d0f66834b24d1d`. Full hashes are in `poc-summary.json` and per-object validation.
- Pair result: the deterministic render exposes smooth parallel jaws/worm versus serrated hook/heel jaws/adjuster. The bodies and exact contours remain editorial; therefore this is a pipeline success but not a production geometry approval.

### t0006 - Cup plunger

- Source class/status: C, prototype, human mechanical review pending.
- Source/license record: Cup plunger product category/reference (retailer/manufacturer imagery reference only; no image reused). Source file hashes are null because those copyrighted/reference-only web documents were not redistributed.
- Authoritative/corroborated geometry: simple flexible cup; handle; absence of extended toilet flange.
- Editorial/inferred geometry: cup profile; wall thickness; handle attachment; exact dimensions.
- Automated checks: {"allPartMeshesWatertight": true, "allPartsBrepValid": true, "deliveryMetadataNeutral": true, "noUnexpectedIntersection": true, "partCountMatches": true, "unitsAreMm": true}.
- Bounding box mm: {"xlen": 136.105941, "xmax": 68.05297, "xmin": -68.05297, "ylen": 136.079058, "ymax": 68.039529, "ymin": -68.039529, "zlen": 530.054947, "zmax": 530.001977, "zmin": -0.05297}.
- Manual QA: `poc-build-a/objects/t0006/qa/manual-checklist.json`; status PENDING_HUMAN_MECHANICAL_REVIEW.
- Key output hashes: STEP `50054970f21ad228f59888ae1dbfaf8e1241c37561706687f32b09509a4335ca`; GLB `afa343401aa3fbbbadf0ba1eadefee905c99745595d39dbad58bd56001723079`; 3/4 SVG `c4cba4df0f5ab4a47551fb9ba4d87178bbbf59ddcd8b66f0c184ef35a1e9769d`; profile SVG `470a3802ee76fb6595f4c37b29468a1a8d7441de1c829bed3a29356a8aaae54a`; feature SVG `0a4a2c6e5b001ed64992346692fc848241cc78c470d3debaf4e8fceb71476a0b`. Full hashes are in `poc-summary.json` and per-object validation.
- Pair result: the deterministic underside/profile renders expose absence versus presence of an extended flange. Exact rubber profiles and dimensions remain editorial; physical measurement is required before production.

### t0007 - Flange plunger

- Source class/status: C, prototype, human mechanical review pending.
- Source/license record: Premium Toilet Plunger #597 (manufacturer page/catalog facts reference only; no image reused). Source file hashes are null because those copyrighted/reference-only web documents were not redistributed.
- Authoritative/corroborated geometry: flexible cup; extended flange beneath cup; handle; selected overall/handle dimensions.
- Editorial/inferred geometry: cup and flange contour; wall thickness; attachment; flange length.
- Automated checks: {"allPartMeshesWatertight": true, "allPartsBrepValid": true, "deliveryMetadataNeutral": true, "noUnexpectedIntersection": true, "partCountMatches": true, "unitsAreMm": true}.
- Bounding box mm: {"xlen": 154.120172, "xmax": 77.060086, "xmin": -77.060086, "ylen": 154.089731, "ymax": 77.044865, "ymin": -77.044865, "zlen": 654.633191, "zmax": 609.602511, "zmin": -45.030681}.
- Manual QA: `poc-build-a/objects/t0007/qa/manual-checklist.json`; status PENDING_HUMAN_MECHANICAL_REVIEW.
- Key output hashes: STEP `9553e4cfd307e1ce189a2bc29d4f9cf482db465063fca3c7dc247927251ba141`; GLB `3b818568a84feeec2a95d54d97c49cd9a5e2865c1a21a36bfd827fdb2f84d479`; 3/4 SVG `fcbaa957625fdcbc8b1f2e357c5a4e8535f55d418091853884099e6f975f90ee`; profile SVG `a981cc829def0e16d18aa9e5cce0764c88f226b7813a7c344bdaa43d07f9b837`; feature SVG `5c8e8d1ed364518e32292d0300ea93e46f6dba391b94317ff0c478ce50eedf41`. Full hashes are in `poc-summary.json` and per-object validation.
- Pair result: the deterministic underside/profile renders expose absence versus presence of an extended flange. Exact rubber profiles and dimensions remain editorial; physical measurement is required before production.

Known deficiencies: the POC models intentionally use simplified, sharp-edged contours; no independent subject-matter expert signed the manual checklist; no purchased full standard was embedded; no physical tool measurements were performed; and source-specific body contours are not generic authority. The POC proves reproducibility and gate mechanics, not final illustration correctness.

## 12. Proposed asset-manifest schema

The complete JSON Schema is supplied as `asset-manifest.schema.json` (Draft 2020-12). It requires the requested identity, source, per-dimension provenance, exact license/rights, brand review, coordinates, geometry classification, source/derived paths, render configuration, pinned container/toolchain, output hashes, mechanical/rights QA, accessibility descriptions, confusable-pair review, reviewers, correction history, and scored-page leak review.

Critical schema rules:

- Unknown rights and dimensions are represented as null/`unknown`, never filled by inference.
- Every dimension records `normative`, `corroborated`, `measured`, `editorial`, or `unknown` and points to a source locator.
- Source class is exactly A-F; no generative class exists.
- Served paths are relative and traversal-safe; every derived file has SHA-256 and media type.
- Approval is impossible without separate mechanical and rights QA objects plus scored metadata-leak review.
- Accessibility has neutral pre-answer and full atlas/post-answer descriptions as separate fields.

## 13. First 20-asset production tranche with sourcing class and rationale

| Rank | ID | Term | Current | Target | Production approach |
| --- | --- | --- | --- | --- | --- |
| 1 | tool.scrub-brush | Scrub brush | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 2 | tool.staple-gun | Staple gun | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 3 | ppe.protective-gloves | Protective gloves (generic) | E | D | Original rights-cleared multi-view photograph and deterministic line conversion; 3D deferred. |
| 4 | tool.adjustable-wrench | Adjustable wrench | C | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 5 | tool.pipe-wrench | Pipe wrench | C | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 6 | tool.plunger.cup | Plunger - cup | C | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 7 | tool.plunger.flange | Plunger - flange | C | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 8 | access.stepladder | Stepladder | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 9 | access.extension-ladder | Extension ladder | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 10 | tool.hammer.claw | Claw hammer | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 11 | tool.hammer.ball-peen | Ball-peen hammer | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 12 | tool.pliers.slip-joint | Slip-joint pliers | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 13 | tool.pliers.tongue-groove | Tongue-and-groove pliers | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 14 | tool.pliers.needle-nose | Needle-nose pliers | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 15 | tool.pliers.diagonal-cutting | Diagonal cutting pliers | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 16 | tool.push-broom | Push broom | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 17 | tool.deck-brush | Deck brush | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |
| 18 | equipment.floor-machine.low-speed | Low-speed rotary floor machine | E | F | Blocked: retain references, but do not publish until a fair generic invariant/model protocol exists. |
| 19 | equipment.burnisher.high-speed | High-speed burnisher | E | F | Blocked: retain references, but do not publish until a fair generic invariant/model protocol exists. |
| 20 | tool.hand-plane | Hand plane | E | C | Project-authored CadQuery model from standards/product drawings plus documented physical measurement. |

The two floor-machine nodes remain Class F in the first tranche by design. Their inclusion is a visible blocked-item test: the pipeline must tolerate an important concept remaining unpublished rather than producing a fictitious universal silhouette [Confirmed repo boundary; C-TAXONOMY, C-SCOPE].

## 14. Cost and maintenance comparison

Planning assumptions, not vendor quotes: research/rights specialist $75/hour; CAD author $85/hour; mechanical reviewer $110/hour; accessibility/copy reviewer $70/hour; standards/procurement budget $2,000-$8,000; controlled CI/container hosting is minor relative to labor.

| Option | Initial effort | Illustrative cost | Maintenance | Risk |
| --- | --- | --- | --- | --- |
| Dataset/portal import | 80-160 h audit before useful output | $7k-$16k plus licensing | High per-object license/provenance churn | High: misleading metadata, trade dress, mixed rights, geometry defects |
| Project-authored deterministic CAD, first 20 | Approx. 424 h: 100 h pipeline + 168 h simpler models + 132 h articulated models + 24 h blocked floor-machine research | $37k-$45k plus standards/tools | Approx. 120-220 h/year for corrections, upgrades, review | $11k-$20k/year at blended rates | Lowest correctness/rights risk; highest upfront labor |
| Rights-cleared original 2D photography | 8-16 h per simple object plus acquisition | $500-$1,500 per tool when acquisition/photography/processing included | Medium; recapture when standards or style change | Good fallback, but angle consistency/hidden geometry limits |
| Generative style pass | 40-100 h setup plus continuing validation | $4k-$10k initial, then review overhead | High model/runtime drift | Adds failure modes with little instructional value |
| Full 65 Class C program | 900-1,300 h plus setup | $80k-$125k plus standards/acquisition | Ongoing annual review | Feasible, but should follow staged approval data |

These are Inferred planning ranges. Actual cost depends on access to tools, reviewer availability, purchased standards, whether existing CC0 assets pass, and how many soft/powered objects require photogrammetry or specialist modeling.

## 15. Unresolved questions and blocked assets

1. Exact ETIM 10 and ETIM MC class-by-class overlap with all 65 taxonomy nodes was not reproducibly exported from the official services; obtain and archive the licensed/downloaded release, then run the supplied query dictionary.
2. Exact ECLASS 16 Advanced coverage and redistribution rights require a licensed release and agreement review.
3. ABO has an observed license conflict between the official dataset page and AWS Registry; no production use until the controller resolves it in writing.
4. Poly Haven pipe-wrench, plunger, and broom meshes require download hashes, scale/unit validation, topology checks, logo/trade-dress review, and comparison against physical references before Class B consideration.
5. No complete authoritative parametric hand-tool specification was located. Confirm whether purchased full standards contain additional reference profiles worth encoding.
6. The project needs a physical-measurement protocol: calibrated tools, measurement uncertainty, required views, reference scale, serial/model capture, and reviewer signoff.
7. Soft/deformable tools need a canonical unloaded pose and deformation policy. A scan of a deformed mop/glove/plunger is not automatically a generic canonical shape.
8. Powered floor machines/burnishers remain blocked for scored silhouette identification until a fair invariant survives multi-manufacturer review. Broad task-context questions may be possible sooner.
9. Crosscut versus rip saw remains blocked if target display size cannot preserve tooth geometry. Do not compensate by inventing exaggerated teeth.
10. Human mechanical reviewer qualifications and conflict-of-interest rules are not defined.
11. Legal review is needed for CC BY-SA asset isolation/attribution practice and for any manufacturer-derived reconstruction that may retain distinctive trade dress.
12. Container digest is not available in this research runtime; production CI must build and pin one before any asset approval.

Blocked current assets: all 45 nonpriority concepts were not individually source-audited and remain Class F; the two floor-machine priority concepts are also planned Class F; all 16 priority Class E concepts remain reference-only until their asset-specific source plan is completed. The four Class C proof models remain unapproved pending physical/source closure and human review.

## 16. Delta against canonical documents

### Delta against `docs/TAXONOMY.md`

- Adds proposed stable IDs, exclusive visual families, source classes A-F, and per-asset production status.
- Identifies one exact duplicate `Staple gun` heading and an overlapping glove concept that should be resolved without losing official-sample provenance.
- Converts existing QA prose into machine-checkable invariants, protected edges, moving-part relationships, and minimum views.
- Preserves the existing prohibition on a fictitious floor-machine/burnisher silhouette and on inaccurate crosscut/rip tooth art.
- Adds an explicit blocked state to the illustration inventory; atlas presence does not imply scored eligibility.

### Delta against `docs/LANDSCAPE.md`

- Makes the line-art process deterministic and implementation-neutral: B-rep hidden-line SVG controls, with raster derivatives.
- Recommends static-first atlas pages with optional user-invoked GLB; scored pages remain fixed static.
- Adds neutral GLB metadata/opaque URL requirements to the existing pre-answer accessibility split.
- Adds offline/mobile budgets and prevents automatic 3D loading.
- Rejects a generative style pass as unnecessary for the documented monochrome style.

### Delta against `docs/OPEN.md`

- New open items: ETIM/ECLASS exact coverage; ABO license conflict; physical measurement protocol; soft-tool pose policy; mechanical-review qualifications; CC BY-SA handling; per-asset dataset review; pinned production container; and floor-machine fairness evidence.
- No existing exam-scope or security question was silently resolved. The confusable registry remains editorial, and no secure/remembered exam image was requested or reconstructed.

No canonical repository file was changed. These are proposed deltas for a later maintainer-controlled reconciliation pass.

## Source ledger

Every time-sensitive source below was observed on 2026-08-20. Standards and historical documents also carry that observation date because edition/status can change.

| ID | Title | Organization | Type | Status | Rights note | URL |
| --- | --- | --- | --- | --- | --- | --- |
| C-BASE | GitHub main branch at required immutable SHA | GitHub / mannyc2 | canonical repository | Confirmed | Repository content; read only for this pass | https://github.com/mannyc2/nycustodianexam/commit/92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c |
| C-AGENTS | AGENTS.md at immutable SHA | mannyc2/nycustodianexam | canonical repository | Confirmed | Repository content; read only | https://github.com/mannyc2/nycustodianexam/blob/92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c/AGENTS.md |
| C-TAXONOMY | docs/TAXONOMY.md at immutable SHA | mannyc2/nycustodianexam | canonical repository | Confirmed | Repository content; read only | https://github.com/mannyc2/nycustodianexam/blob/92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c/docs/TAXONOMY.md |
| C-LANDSCAPE | docs/LANDSCAPE.md at immutable SHA | mannyc2/nycustodianexam | canonical repository | Confirmed | Repository content; read only | https://github.com/mannyc2/nycustodianexam/blob/92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c/docs/LANDSCAPE.md |
| C-OPEN | docs/OPEN.md at immutable SHA | mannyc2/nycustodianexam | canonical repository | Confirmed | Repository content; read only | https://github.com/mannyc2/nycustodianexam/blob/92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c/docs/OPEN.md |
| C-SCOPE | docs/SCOPE.md at immutable SHA | mannyc2/nycustodianexam | canonical repository | Confirmed | Repository content; read only | https://github.com/mannyc2/nycustodianexam/blob/92efee4fb2cfd0f6032d0f9348cb8cc8ba89356c/docs/SCOPE.md |
| S-ISO6787 | ISO 6787:2018 Adjustable wrenches | ISO | standard | Confirmed | Copyrighted standard; abstract public; full text paid/restricted | https://www.iso.org/standard/71911.html |
| S-ASME107100 | ASME B107.100-2023 Flat Wrenches | ASME / ANSI Webstore | standard | Confirmed | Copyrighted standard; purchase/subscription | https://webstore.ansi.org/standards/asme/asmeb1071002023 |
| S-ASME107400 | ASME B107.400-2018 (R2023) Striking Tools | ASME / ANSI Webstore | standard | Confirmed | Copyrighted standard; purchase/subscription | https://webstore.ansi.org/standards/asme/asmeb1074002018r2023 |
| S-ASME107500 | ASME B107.500-2020 Pliers and Shears | ASME / ANSI Webstore | standard | Confirmed | Copyrighted standard; purchase/subscription | https://webstore.ansi.org/standards/asme/asmeb1075002020 |
| S-ISO5743 | ISO 5743:2021 Pliers and nippers - General technical requirements | ISO | standard | Confirmed | Copyrighted standard; abstract public; full text paid/restricted | https://www.iso.org/standard/75368.html |
| S-ISO5749 | ISO 5749:2004 Pliers and nippers - Diagonal cutting nippers | ISO | standard | Confirmed | Copyrighted standard; abstract public; full text paid/restricted | https://www.iso.org/standard/39851.html |
| S-ANSI-A14 | ANSI-ASC A14 Portable Ladder Standards Package | ANSI / American Ladder Institute | standard package | Confirmed | Copyrighted standards; purchase/subscription | https://webstore.ansi.org/standards/asc/ansi-asc-a14-package |
| S-OSHA-STEP | Stepladder definition and requirements | US OSHA | government regulation/guidance | Confirmed | US government text; verify third-party material | https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.21 |
| S-OSHA-EXT | Extension ladder definition and requirements | US OSHA | government regulation/guidance | Confirmed | US government text; verify third-party material | https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.21 |
| S-GGG-W651E | Federal Specification GGG-W-651E, Wrenches, Pipe (cancelled) | US GSA / DLA ASSIST | government specification | Confirmed as cancelled reference | US government document; document status and embedded material still require review | https://quicksearch.dla.mil/qsDocDetails.aspx?ident_number=21236 |
| D-ETIM10 | ETIM 10.0 international product classification | ETIM International | classification/data system | Confirmed | Use governed by ETIM license; English CSV/IXF download offered | https://www.etim-international.com/new-release-etim-10-0-available/ |
| D-ETIMMC2 | ETIM MC Guidelines 2.0 | ETIM International | geometric modeling classification | Confirmed | Guidelines/download terms require review; not a blanket asset license | https://www.etim-international.com/etim-mc-guidelines-version-2-0-officially-released/ |
| D-ETIM-LICENSE | ETIM license information | ETIM International | license | Not fully recovered | Production use must record exact current ETIM license | https://www.etim-international.com/classification/license-info/ |
| D-ECLASS16 | ECLASS Release 16.0 | ECLASS e.V. | classification/data system | Confirmed | License required for ECLASS content | https://eclass.eu/en/eclass-standard/releases |
| D-ECLASS-ADV | ECLASS Basic and Advanced | ECLASS e.V. | CAx product data | Confirmed | License required; Advanced content is not a public-domain geometry corpus | https://eclass.eu/en/eclass-standard/basic-and-advanced |
| D-ECLASS-LICENSE | ECLASS licenses | ECLASS e.V. | license | Confirmed | Paid/licensed use; redistribution governed by agreement | https://eclass.eu/en/eclass-standard/licenses |
| F-STEP242 | ISO 10303-242:2025 AP242 edition 4 | ISO | CAD interchange standard | Confirmed | Standard text copyrighted; original STEP data may carry its own rights | https://www.iso.org/standard/84300.html |
| F-IFC | ISO 16739-1:2024 IFC | ISO / buildingSMART | BIM interchange schema | Confirmed | Standard text/schema terms apply; generated model rights remain separate | https://www.iso.org/standard/84123.html |
| F-GLTF | glTF 2.0 Specification | Khronos Group | web delivery format | Confirmed | Open specification; asset rights remain separate | https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html |
| L-TRACEPARTS | TraceParts General Terms and Conditions of Use | TraceParts | CAD portal terms | Confirmed | Restrictions prohibit treating downloads as a redistributable production corpus | https://info.traceparts.com/legal/general-terms-and-conditions-of-use/ |
| L-3DCC | 3D ContentCentral Terms of Use | Dassault Systemes | CAD portal terms | Confirmed | Public/commercial redistribution and modification restricted | https://www.3dcontentcentral.com/TermsOfUse.aspx |
| L-PARTCOMMUNITY | PARTcommunity Terms of Use | CADENAS | CAD portal terms | Confirmed | Project/personal use limits; public redistribution/alteration restricted | https://b2b.partcommunity.com/community/terms |
| DS-GSO | Google Scanned Objects release/repository | Google Research | 3D dataset | Confirmed collection; taxonomy counts not located | Repository/sim assets CC BY 4.0; underlying CAD/textures may have separate licenses | https://github.com/google-research-datasets/Google-Scanned-Objects |
| DS-ABO | Amazon Berkeley Objects | Amazon / UC Berkeley | 3D dataset | Confirmed collection; license conflict unresolved | Official page says CC BY 4.0; AWS Registry listing observed CC BY-NC-4.0 conflict | https://amazon-berkeley-objects.s3.amazonaws.com/index.html |
| DS-ABO-AWS | ABO Registry of Open Data entry | AWS | dataset registry | Corroborated metadata; conflicts with official page | Observed CC BY-NC-4.0 label; resolve before production | https://registry.opendata.aws/amazon-berkeley-objects/ |
| DS-OBJAVERSE | Objaverse | Allen Institute for AI | 3D dataset | Confirmed project; per-object review required | Mixed source/platform licenses; collection name is not a blanket license | https://github.com/allenai/objaverse-xl |
| DS-OBJAVERSE-XL | Objaverse-XL | Allen Institute for AI | 3D dataset | Confirmed project; per-object review required | Mixed sources and licenses | https://objaverse.allenai.org/objaverse-xl |
| DS-SMITHSONIAN | Smithsonian Open Access and 3D | Smithsonian Institution | institutional 3D/open access | Confirmed | Open Access items CC0; not every collection item is Open Access | https://www.si.edu/openaccess |
| DS-POLYHAVEN | Poly Haven License | Poly Haven | 3D asset library | Confirmed | CC0 for Poly Haven assets | https://polyhaven.com/license |
| DS-POLY-ADJ | Adjustable Wrench asset | Poly Haven | 3D asset | Rejected as generic geometry | CC0; mechanical suitability failed | https://polyhaven.com/a/adjustable_wrench |
| DS-POLY-PIPE | Pipe Wrench asset | Poly Haven | 3D asset | Candidate not accepted | CC0; download/mesh/mechanical review still required | https://polyhaven.com/a/pipe_wrench |
| DS-POLY-PLUNGER | Plunger asset | Poly Haven | 3D asset | Candidate not accepted | CC0; category and flange geometry require review | https://polyhaven.com/a/plunger |
| DS-POLY-BROOM | Plastic Broom asset | Poly Haven | 3D asset | Candidate not accepted | CC0; subtype and mechanical review required | https://polyhaven.com/a/plastic_broom |
| DS-SKETCHFAB-API | Sketchfab Data API search | Sketchfab | 3D marketplace/API | Confirmed | Per-asset license controls; platform availability is not a license | https://sketchfab.com/developers/data-api/v3 |
| DS-WIKIMEDIA3D | Wikimedia Commons 3D extension | Wikimedia Foundation | 3D file repository | Confirmed | Per-file license and source page control | https://www.mediawiki.org/wiki/Extension:3D |
| DS-SHAPENET | ShapeNet Terms of Use | ShapeNet / Stanford | research dataset | Confirmed | Academic noncommercial research restrictions; unsuitable for production | https://shapenet.org/terms |
| R-CCBY4 | Creative Commons Attribution 4.0 | Creative Commons | license | Confirmed | Commercial use and adaptations allowed with attribution and other terms | https://creativecommons.org/licenses/by/4.0/ |
| R-CCBYSA4 | Creative Commons Attribution-ShareAlike 4.0 | Creative Commons | license | Confirmed | Adaptations must be distributed under same license; attribution required | https://creativecommons.org/licenses/by-sa/4.0/ |
| R-USGOV | 17 USC 105 | US Congress / Cornell LII | copyright law | Confirmed | US government works not protected under Title 17; third-party material caveat remains | https://www.law.cornell.edu/uscode/text/17/105 |
| R-COPYRIGHT-GOV | Copyright in US Government Works | US Copyright Office | copyright guidance | Confirmed | Government publications can include protected third-party material | https://www.copyright.gov/circs/circ01.pdf |
| R-OPENVERSE | Openverse license verification guidance | WordPress/Openverse | discovery service | Confirmed | Discovery only; verify license at original source | https://docs.openverse.org/ |
| P-ARROW-T50 | T50PBN Professional Staple and Nail Gun | Arrow Fastener | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://arrowfastener.com/tool/t50pbn/ |
| P-OSHA-GLOVES | Hand protection selection | US OSHA | government safety guidance | Confirmed | US government text; verify any third-party media | https://www.osha.gov/personal-protective-equipment/hand-protection |
| P-STANLEY-PLANE | No. 4 Sweetheart Smoothing Bench Plane | STANLEY | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://www.stanleytools.com/product/12-136/no-4-sweetheart-smoothing-bench-plane |
| P-LIBMAN-SCRUB | Long Handle Scrub Brush | Libman | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://libman.com/products/long-handle-scrub-brush |
| P-LIBMAN-PUSH | Commercial Push Brooms | Libman | manufacturer reference | Corroborated product family | Reference only absent express reuse license | https://libman.com/collections/brooms |
| P-TENNANT-FM20 | FM-20-SS Single Speed Floor Machine | Tennant | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://www.tennantco.com/en_us/1/machines/floor-machines/fm-20-ss.html |
| P-TENNANT-B5 | B5 Walk-Behind Battery Burnisher | Tennant | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://www.tennantco.com/en_us/1/machines/burnishers/b5.html |
| P-NILFISK-FM400D | FM400 D dual-speed floor machine | Nilfisk | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://www.nilfisk.com/global/professional/products/floor-cleaning/single-discs/fm400-d/ |
| P-BAHCO-8072 | Bahco 8072 Adjustable Wrench product data | Bahco | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://www.bahco.com/int_en/ergotm-central-nut-adjustable-wrenches-with-rubber-handle-and-extra-wide-jaw-pb_80_series_.html |
| P-RIDGID-PIPE | Heavy-Duty Straight Pipe Wrenches | RIDGID | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://www.ridgid.com/us/en/straight-pipe-wrench |
| P-HDX-CUP | 5 in Force Cup Plunger | HDX / Home Depot | retailer/product reference | Corroborated product-specific | Reference only; no image reused | https://www.homedepot.com/p/HDX-5-in-Force-Cup-Plunger-BC2451-5/302785815 |
| P-LIBMAN-PLUNGER | Premium Toilet Plunger | Libman | manufacturer reference | Confirmed product-specific | Reference only absent express reuse license | https://libman.com/products/premium-toilet-plunger |
| SW-CADQUERY | CadQuery 2.8.0 | CadQuery project | software | Confirmed | Apache-2.0 project; dependency licenses also apply | https://github.com/CadQuery/cadquery/releases/tag/2.8.0 |
| SW-BUILD123D | build123d 0.10.0 | build123d project | software | Confirmed | Apache-2.0 project; dependency licenses also apply | https://pypi.org/project/build123d/ |
| SW-FREECAD | FreeCAD 1.1.0 | FreeCAD project | software | Confirmed | LGPL-2.0-or-later plus component licenses | https://github.com/FreeCAD/FreeCAD/releases/tag/1.1.0 |
| SW-OCCT | Open CASCADE Technology 7.9.3 | Open CASCADE | software/kernel | Confirmed | LGPL-2.1 with exception | https://dev.opencascade.org/release/open-cascade-technology-793 |
| SW-BLENDER | Blender 4.5 LTS / 5.x | Blender Foundation | software | Confirmed | GPL-2.0-or-later; generated output not automatically GPL | https://www.blender.org/download/lts/4-5/ |
| SW-OPENSCAD | OpenSCAD 2021.01 | OpenSCAD project | software | Confirmed | GPL-2.0-or-later | https://github.com/openscad/openscad/releases/tag/openscad-2021.01 |

## Artifact index

- `taxonomy-inventory.csv`: all 65 normalized assets and current source class.
- `confusable-pairs.csv`: all 14 canonical registry entries.
- `first-20-visual-invariants.csv`: machine-friendly invariant sheets.
- `source-ledger.csv`: source titles, URLs, rights notes, status, and observation dates.
- `asset-manifest.schema.json`: full proposed production schema.
- `poc-summary.json`: POC validations and hashes.
- `poc-build-a/`: complete inspectable POC evidence.
- `poc-build-b/`: independent second build used for exact comparison.
