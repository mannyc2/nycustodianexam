# Deterministic tool-illustration POC

Observation date: 2026-08-20

This read-only research artifact was created outside the repository. It contains no third-party geometry, images, textures, logos, or official exam artwork.

Objects:
- `t0004`: adjustable wrench
- `t0005`: pipe wrench
- `t0006`: cup plunger
- `t0007`: flange plunger

The descriptive mapping exists only in private build metadata. Web-delivery filenames and GLB node names are neutral.

## Reproduction

```sh
export SOURCE_DATE_EPOCH=1787184000
python build_poc.py --out ./build-a
python build_poc.py --out ./build-b
python compare_builds.py ./build-a ./build-b
```

The build performs no network access. The controlled platform is documented in `build-environment.json`.

## Acceptance status

This is a pipeline proof, not a production geometry approval. Automated B-rep, mesh, intersection, output-hash, and metadata-leak results are under each object's `qa/` directory. Human mechanical and rights review remains mandatory. Unconstrained contours are explicitly marked editorial in each `source-record.json`.

## Rights

Newly authored POC geometry and scripts are dedicated under CC0-1.0 for this research artifact. External standards and manufacturer pages are factual references only and are not redistributed.
